<?php

namespace App\Services;

use App\Models\Offer;
use App\Models\OfferContainer;
use App\Models\Customer;
use App\Models\Container;
use App\Enums\OfferStatus;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class OfferService
{
    /**
     * Get all offers with pagination
     */
    public function getAll(int $perPage = 15): LengthAwarePaginator
    {
        return Offer::with(['customer', 'offerContainers.container'])
            ->latest()
            ->paginate($perPage);
    }

    /**
     * Get all offers without pagination
     */
    public function getAllWithoutPagination(): Collection
    {
        return Offer::with(['customer', 'offerContainers.container'])->latest()->get();
    }

    /**
     * Find an offer by ID
     */
    public function findById(int $id): ?Offer
    {
        return Offer::with(['customer', 'offerContainers.container'])->find($id);
    }

    /**
     * Create a new offer with containers
     */
    public function create(array $data): Offer
    {
        return DB::transaction(function () use ($data) {
            // Generate offer number if not provided
            if (!isset($data['offer_number'])) {
                $data['offer_number'] = $this->generateOfferNumber();
            }

            // Set default dates if not provided
            if (!isset($data['offer_date'])) {
                $data['offer_date'] = now()->toDateString();
            }
            if (!isset($data['valid_until'])) {
                $data['valid_until'] = now()->addDays(30)->toDateString();
            }

            // Create the offer
            $offer = Offer::create($data);

            // Add containers to the offer
            if (isset($data['containers']) && is_array($data['containers'])) {
                foreach ($data['containers'] as $containerData) {
                    $monthlyPrice = $containerData['no_of_containers'] * $containerData['price_per_container'];
                    $totalMonthlyDumping = $containerData['no_of_containers'] * $containerData['monthly_dumping_per_container'];

                    $offer->offerContainers()->create([
                        'container_id' => $containerData['container_id'],
                        'no_of_containers' => $containerData['no_of_containers'],
                        'monthly_dumping_per_container' => $containerData['monthly_dumping_per_container'],
                        'total_monthly_dumping' => $totalMonthlyDumping,
                        'price_per_container' => $containerData['price_per_container'],
                        'monthly_price' => $monthlyPrice,
                    ]);
                }
            }

            // Calculate and update total prices
            $totalMonthlyPrice = $offer->calculateTotalMonthlyPrice();
            $offer->update([
                'total_monthly_price' => $totalMonthlyPrice,
                'total_price' => $totalMonthlyPrice
            ]);

            return $offer->load(['customer', 'offerContainers.container']);
        });
    }

    /**
     * Update an offer
     */
    public function update(Offer $offer, array $data): bool
    {
        return DB::transaction(function () use ($offer, $data) {
            // Update the offer
            $offer->update($data);

            // Update containers if provided
            if (isset($data['containers']) && is_array($data['containers'])) {
                // Delete existing containers
                $offer->offerContainers()->delete();

                // Add new containers
                foreach ($data['containers'] as $containerData) {
                    $monthlyPrice = $containerData['no_of_containers'] * $containerData['price_per_container'];
                    $totalMonthlyDumping = $containerData['no_of_containers'] * $containerData['monthly_dumping_per_container'];

                    $offer->offerContainers()->create([
                        'container_id' => $containerData['container_id'],
                        'no_of_containers' => $containerData['no_of_containers'],
                        'monthly_dumping_per_container' => $containerData['monthly_dumping_per_container'],
                        'total_monthly_dumping' => $totalMonthlyDumping,
                        'price_per_container' => $containerData['price_per_container'],
                        'monthly_price' => $monthlyPrice,
                    ]);
                }
            }

            // Recalculate and update total prices
            $totalMonthlyPrice = $offer->calculateTotalMonthlyPrice();
            $offer->update([
                'total_monthly_price' => $totalMonthlyPrice,
                'total_price' => $totalMonthlyPrice
            ]);

            return true;
        });
    }

    /**
     * Delete an offer
     */
    public function delete(Offer $offer): bool
    {
        return DB::transaction(function () use ($offer) {
            // Delete offer containers first
            $offer->offerContainers()->delete();

            // Delete the offer
            return $offer->delete();
        });
    }

    /**
     * Get available offer statuses
     */
    public function getStatuses(): array
    {
        return collect(OfferStatus::cases())
            ->mapWithKeys(fn($status) => [$status->value => $status->label()])
            ->toArray();
    }

    /**
     * Get all customers for dropdown
     */
    public function getCustomers(): Collection
    {
        return Customer::orderBy('name')->get();
    }

    /**
     * Get all containers for dropdown
     */
    public function getContainers(): Collection
    {
        return Container::orderBy('code')->get();
    }

    /**
     * Generate unique offer number
     */
    public function generateOfferNumber(): string
    {
        $lastOffer = Offer::orderBy('id', 'desc')->first();
        $nextNumber = $lastOffer ? $lastOffer->id + 1 : 1;
        return 'OFF-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Generate offer PDF
     */
    public function generateOfferPdf(Offer $offer): \Barryvdh\DomPDF\PDF
    {
        $offer->load(['customer', 'offerContainers.container']);

        $data = [
            'offer' => $offer,
            'company' => [
                'name' => 'RTM Arabia Est',
                'arabic_name' => 'مؤسسة رتم العربية للتأجير',
                'address' => '123 Business Street, City, State 12345',
                'phone' => '+966 (555) 123-4567',
                'email' => 'info@rtmarabia.com',
                'manager' => 'Rakan M Al-Marzuqi',
                'arabic_manager' => 'راكان منصور المرزوقي',
            ],
            'generated_date' => now()->format('Y/m/d'),
        ];

        return Pdf::loadView('offers.offer-pdf', $data)
            ->setPaper('a4', 'portrait')
            ->setOptions([
                'defaultFont' => 'Arial',
                'isHtml5ParserEnabled' => true,
                'isRemoteEnabled' => true,
            ]);
    }

    /**
     * Download offer PDF
     */
    public function downloadOfferPdf(Offer $offer): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        $pdf = $this->generateOfferPdf($offer);
        $filename = 'offer-' . $offer->offer_number . '-' . now()->format('Y-m-d') . '.pdf';

        return $pdf->download($filename);
    }

    /**
     * Stream offer PDF
     */
    public function streamOfferPdf(Offer $offer): \Symfony\Component\HttpFoundation\Response
    {
        $pdf = $this->generateOfferPdf($offer);

        return $pdf->stream('offer-' . $offer->offer_number . '.pdf');
    }
}
