<?php

namespace App\Services;

use App\Models\Contract;
use App\Models\ContractContainer;
use App\Models\Customer;
use App\Models\Container;
use App\Enums\ContractStatus;
use App\Enums\ContainerStatus;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ContractService
{
    /**
     * Get all contracts with pagination
     */
    public function getAll(int $perPage = 15): LengthAwarePaginator
    {
        return Contract::with(['customer', 'contractContainers.container'])
            ->latest()
            ->paginate($perPage);
    }

    /**
     * Get all contracts without pagination
     */
    public function getAllWithoutPagination(): Collection
    {
        return Contract::with(['customer', 'contractContainers.container'])->latest()->get();
    }

    /**
     * Find a contract by ID
     */
    public function findById(int $id): ?Contract
    {
        return Contract::with(['customer', 'contractContainers.container'])->find($id);
    }

    /**
     * Create a new contract with containers
     */
    public function create(array $data): Contract
    {
        return DB::transaction(function () use ($data) {
            // Calculate contract period days
            $startDate = Carbon::parse($data['start_date']);
            $endDate = Carbon::parse($data['end_date']);
            $data['contract_period_days'] = $startDate->diffInDays($endDate);

            // Create the contract
            $contract = Contract::create($data);

            // Add containers to the contract
            if (isset($data['containers']) && is_array($data['containers'])) {
                foreach ($data['containers'] as $containerData) {
                    $contractContainer = $contract->contractContainers()->create([
                        'type_id' => $containerData['type_id'],
                        'no_of_containers' => $containerData['no_of_containers'],
                        'monthly_dumping' => $containerData['monthly_dumping'],
                        'price_per_container' => $containerData['price_per_container'],
                        'additional_trip_price' => $containerData['additional_trip_price'] ?? null,
                        'status' => 'assigned'
                    ]);

                    // Try to assign available container automatically
                    $this->assignAvailableContainer($contractContainer);
                }
            }

            // Calculate and update total price
            $contract->update(['total_price' => $contract->calculateTotalPrice()]);

            return $contract->load(['customer', 'contractContainers.container']);
        });
    }

    /**
     * Update a contract
     */
    public function update(Contract $contract, array $data): bool
    {
        return DB::transaction(function () use ($contract, $data) {
            // Calculate contract period days if dates are updated
            if (isset($data['start_date']) || isset($data['end_date'])) {
                $startDate = Carbon::parse($data['start_date'] ?? $contract->start_date);
                $endDate = Carbon::parse($data['end_date'] ?? $contract->end_date);
                $data['contract_period_days'] = $startDate->diffInDays($endDate);
            }

            // Update the contract
            $contract->update($data);

            // Update containers if provided
            if (isset($data['containers']) && is_array($data['containers'])) {
                // Delete existing containers
                $contract->contractContainers()->delete();

                // Add new containers
                foreach ($data['containers'] as $containerData) {
                    $contract->contractContainers()->create([
                        'container_id' => $containerData['container_id'],
                        'no_of_containers' => $containerData['no_of_containers'],
                        'monthly_dumping' => $containerData['monthly_dumping'],
                        'price_per_container' => $containerData['price_per_container'],
                        'additional_trip_price' => $containerData['additional_trip_price'] ?? null,
                    ]);
                }
            }

            // Recalculate and update total price
            $contract->update(['total_price' => $contract->calculateTotalPrice()]);

            return true;
        });
    }

    /**
     * Delete a contract
     */
    public function delete(Contract $contract): bool
    {
        return DB::transaction(function () use ($contract) {
            // Delete contract containers first
            $contract->contractContainers()->delete();

            // Delete the contract
            return $contract->delete();
        });
    }

    /**
     * Get available contract statuses
     */
    public function getStatuses(): array
    {
        return collect(ContractStatus::cases())
            ->mapWithKeys(fn($status) => [$status->value => $status->label()])
            ->toArray();
    }

    /**
     * Get all customers for dropdown
     */
    public function getCustomers(): Collection
    {
        return Customer::orderBy('name')->get();
    }

    /**
     * Get all containers for dropdown
     */
    public function getContainers(): Collection
    {
        return Container::orderBy('code')->get();
    }

    /**
     * Generate quotation PDF
     */
    public function generateQuotationPdf(Contract $contract): \Barryvdh\DomPDF\PDF
    {
        $contract->load(['customer', 'contractContainers.container']);

        $data = [
            'contract' => $contract,
            'company' => [
                'name' => 'Container Management System',
                'address' => '123 Business Street, City, State 12345',
                'phone' => '+1 (555) 123-4567',
                'email' => 'info@containersystem.com',
            ],
            'quotation_number' => 'QUO-' . str_pad($contract->id, 6, '0', STR_PAD_LEFT),
            'generated_date' => now()->format('M d, Y'),
        ];

        return Pdf::loadView('contracts.quotation-pdf', $data)
            ->setPaper('a4', 'portrait')
            ->setOptions([
                'defaultFont' => 'Arial',
                'isHtml5ParserEnabled' => true,
                'isRemoteEnabled' => true,
            ]);
    }

    /**
     * Download quotation PDF
     */
    public function downloadQuotationPdf(Contract $contract): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        $pdf = $this->generateQuotationPdf($contract);
        $filename = 'quotation-' . $contract->id . '-' . now()->format('Y-m-d') . '.pdf';

        return $pdf->download($filename);
    }

    /**
     * Stream quotation PDF
     */
    public function streamQuotationPdf(Contract $contract): \Symfony\Component\HttpFoundation\Response
    {
        $pdf = $this->generateQuotationPdf($contract);

        return $pdf->stream('quotation-' . $contract->id . '.pdf');
    }

    /**
     * Assign available container to contract container
     */
    private function assignAvailableContainer(ContractContainer $contractContainer): void
    {
        $availableContainer = Container::where('type_id', $contractContainer->type_id)
            ->where('status', ContainerStatus::AVAILABLE)
            ->first();

        if ($availableContainer) {
            $availableContainer->update(['status' => ContainerStatus::IN_USE]);
            $contractContainer->update(['container_id' => $availableContainer->id]);
        }
    }
}
