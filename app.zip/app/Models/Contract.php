<?php

namespace App\Models;

use App\Enums\ContractStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Casts\Attribute;

class Contract extends Model
{
    protected $fillable = [
        'customer_id',
        'type_id',
        'customer',
        'container_price',
        'no_containers',
        'monthly_dumping_cont',
        'dumping_cost',
        'monthly_total_dumping_cost',
        'additional_trip_cost',
        'contract_period',
        'tax_value',
        'total_price',
        'total_payed',
        'start_date',
        'end_date',
        'status',
        'notes',
        'user_id',
        'agreement_terms',
        'material_restrictions',
        'delivery_terms',
        'payment_policy',
        'valid_until',
        // Company information
        'company_name',
        'company_logo',
        'company_address',
        'company_phone',
        'company_email',
        'company_website',
        'company_pobox',
        // Quotation specific fields
        'quotation_number',
        'quotation_serial',
        'quotation_date',
        'validity_days',
        'customer_details',
        'container_size',
        'price_per_container',
        'monthly_dumping_per_container',
        'total_dumping',
        'additional_trips_price',
        'contract_period_months',
        'total_monthly_price',
        'total_monthly_with_tax',
        'total_yearly_with_tax',
        // Terms and conditions (Arabic)
        'agreement_terms_ar',
        'material_restrictions_ar',
        'receiving_terms_ar',
        'notes_ar',
        'payment_policy_ar',
        // Discounts
        'advance_payment_one_year_discount',
        'advance_payment_six_months_discount',
        // Signatures
        'manager_name',
        'manager_signature',
        'supervisor_name',
        'supervisor_signature',
        'supervisor_mobile',
        // Legacy fields for backward compatibility
        'customer_name',
        'contact_person',
        'telephone',
        'extension',
        'fax',
        'mobile',
        'city',
        'address',
        'contract_period_days',
        'additional_trip_price',
        'driver_id',
    ];

    protected $casts = [
        'quotation_date' => 'date',
        'start_date' => 'date',
        'end_date' => 'date',
        'valid_until' => 'date',
        'total_price' => 'decimal:2',
        'total_payed' => 'decimal:2',
        'container_price' => 'decimal:2',
        'monthly_dumping_cont' => 'decimal:2',
        'dumping_cost' => 'decimal:2',
        'monthly_total_dumping_cost' => 'decimal:2',
        'additional_trip_cost' => 'decimal:2',
        'tax_value' => 'decimal:2',
        'customer' => 'array',
        'customer_details' => 'array',
        'status' => ContractStatus::class,
        // New quotation fields
        'price_per_container' => 'decimal:2',
        'additional_trips_price' => 'decimal:2',
        'total_monthly_price' => 'decimal:2',
        'total_monthly_with_tax' => 'decimal:2',
        'total_yearly_with_tax' => 'decimal:2',
        'advance_payment_one_year_discount' => 'decimal:2',
        'advance_payment_six_months_discount' => 'decimal:2',
        // Legacy fields
        'additional_trip_price' => 'decimal:2',
    ];

    protected function status(): Attribute
    {
        return Attribute::make(
            get: fn (ContractStatus $value) => $value->label(),
        );
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function contractContainers(): HasMany
    {
        return $this->hasMany(ContractContainer::class);
    }

    public function containers()
    {
        return $this->belongsToMany(Container::class, 'contract_containers')
                    ->withPivot(['no_of_containers', 'monthly_dumping', 'price_per_container', 'additional_trip_price'])
                    ->withTimestamps();
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(Type::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function contractContainerFills(): HasMany
    {
        return $this->hasMany(ContractContainerFill::class);
    }

    public function calculateTotalPrice(): float
    {
        $total = 0;
        foreach ($this->contractContainers as $contractContainer) {
            $containerTotal = $contractContainer->no_of_containers * $contractContainer->price_per_container;
            $dumpingTotal = $contractContainer->monthly_dumping * ($contractContainer->additional_trip_price ?? 0);
            $total += $containerTotal + $dumpingTotal;
        }
        return $total;
    }
}
