<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OfferContainer extends Model
{
    protected $fillable = [
        'offer_id',
        'container_id',
        'no_of_containers',
        'monthly_dumping_per_container',
        'total_monthly_dumping',
        'price_per_container',
        'monthly_price',
    ];

    protected $casts = [
        'price_per_container' => 'decimal:2',
        'monthly_price' => 'decimal:2',
    ];

    public function offer(): BelongsTo
    {
        return $this->belongsTo(Offer::class);
    }

    public function container(): BelongsTo
    {
        return $this->belongsTo(Container::class);
    }

    public function getTotalPriceAttribute(): float
    {
        return $this->no_of_containers * $this->price_per_container;
    }
}
