<?php

namespace App\Models;

use App\Enums\OfferStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Casts\Attribute;

class Offer extends Model
{
    protected $fillable = [
        'customer_id',
        'quotation_number',
        'quotation_date',
        'offer_number',
        'offer_date',
        'valid_until',
        'customer_name',
        'contact_person',
        'telephone',
        'extension',
        'fax',
        'mobile',
        'city',
        'address',
        'contract_period_days',
        'additional_trip_price',
        'total_monthly_price',
        'total_price',
        'status',
        'notes',
        'agreement_terms',
        'material_restrictions',
        'delivery_terms',
        'payment_policy',
    ];

    protected $casts = [
        'quotation_date' => 'date',
        'offer_date' => 'date',
        'valid_until' => 'date',
        'additional_trip_price' => 'decimal:2',
        'total_monthly_price' => 'decimal:2',
        'total_price' => 'decimal:2',
        'status' => OfferStatus::class,
    ];

    protected function status(): Attribute
    {
        return Attribute::make(
            get: fn (OfferStatus $value) => $value->label(),
        );
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function offerContainers(): HasMany
    {
        return $this->hasMany(OfferContainer::class);
    }

    public function containers()
    {
        return $this->belongsToMany(Container::class, 'offer_containers')
                    ->withPivot(['no_of_containers', 'monthly_dumping_per_container', 'total_monthly_dumping', 'price_per_container', 'monthly_price'])
                    ->withTimestamps();
    }

    public function calculateTotalPrice(): float
    {
        $total = 0;
        foreach ($this->offerContainers as $offerContainer) {
            $total += $offerContainer->monthly_price;
        }
        return $total;
    }

    public function calculateTotalMonthlyPrice(): float
    {
        $total = 0;
        foreach ($this->offerContainers as $offerContainer) {
            $total += $offerContainer->monthly_price;
        }
        return $total;
    }

    public function getTotalMonthlyDumpingAttribute(): int
    {
        return $this->offerContainers->sum('total_monthly_dumping');
    }

    public function getTotalContainersAttribute(): int
    {
        return $this->offerContainers->sum('no_of_containers');
    }
}
