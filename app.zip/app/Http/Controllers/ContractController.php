<?php

namespace App\Http\Controllers;

use App\Models\Contract;
use App\Models\Type;
use App\Models\Customer;
use App\Models\User;
use App\Services\ContractService;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Illuminate\Http\JsonResponse;

class ContractController extends Controller
{
    protected ContractService $contractService;

    public function __construct(ContractService $contractService)
    {
        $this->contractService = $contractService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        $contracts = $this->contractService->getAll();
        return view('contracts.index', compact('contracts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        $statuses = $this->contractService->getStatuses();
        $customers = Customer::all();
        $types = Type::all();
        $users = User::all();
        return view('contracts.create', compact('statuses', 'customers', 'types', 'users'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'customer_id' => 'nullable|exists:customers,id',
            'type_id' => 'nullable|exists:types,id',
            'customer' => 'nullable|array',
            'container_price' => 'nullable|numeric|min:0',
            'no_containers' => 'nullable|integer|min:1',
            'monthly_dumping_cont' => 'nullable|numeric|min:0',
            'dumping_cost' => 'nullable|numeric|min:0',
            'monthly_total_dumping_cost' => 'nullable|numeric|min:0',
            'additional_trip_cost' => 'nullable|numeric|min:0',
            'contract_period' => 'nullable|integer|min:1',
            'tax_value' => 'nullable|numeric|min:0|max:100',
            'total_price' => 'nullable|numeric|min:0',
            'total_payed' => 'nullable|numeric|min:0',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'status' => 'required|string',
            'notes' => 'nullable|string',
            'user_id' => 'nullable|exists:users,id',
            'agreement_terms' => 'nullable|string',
            'material_restrictions' => 'nullable|string',
            'delivery_terms' => 'nullable|string',
            'payment_policy' => 'nullable|string',
            'valid_until' => 'nullable|date',
            // Company information
            'company_name' => 'nullable|string|max:255',
            'company_logo' => 'nullable|string|max:255',
            'company_address' => 'nullable|string|max:255',
            'company_phone' => 'nullable|string|max:255',
            'company_email' => 'nullable|email|max:255',
            'company_website' => 'nullable|string|max:255',
            'company_pobox' => 'nullable|string|max:255',
            // Quotation specific fields
            'quotation_number' => 'nullable|string|max:255',
            'quotation_serial' => 'nullable|string|max:255',
            'quotation_date' => 'nullable|date',
            'validity_days' => 'nullable|integer|min:1',
            'customer_details' => 'nullable|array',
            'container_size' => 'nullable|string|max:255',
            'price_per_container' => 'nullable|numeric|min:0',
            'monthly_dumping_per_container' => 'nullable|integer|min:0',
            'total_dumping' => 'nullable|integer|min:0',
            'additional_trips_price' => 'nullable|numeric|min:0',
            'contract_period_months' => 'nullable|integer|min:1',
            'total_monthly_price' => 'nullable|numeric|min:0',
            'total_monthly_with_tax' => 'nullable|numeric|min:0',
            'total_yearly_with_tax' => 'nullable|numeric|min:0',
            // Terms and conditions (Arabic)
            'agreement_terms_ar' => 'nullable|string',
            'material_restrictions_ar' => 'nullable|string',
            'receiving_terms_ar' => 'nullable|string',
            'notes_ar' => 'nullable|string',
            'payment_policy_ar' => 'nullable|string',
            // Discounts
            'advance_payment_one_year_discount' => 'nullable|numeric|min:0|max:100',
            'advance_payment_six_months_discount' => 'nullable|numeric|min:0|max:100',
            // Signatures
            'manager_name' => 'nullable|string|max:255',
            'manager_signature' => 'nullable|string|max:255',
            'supervisor_name' => 'nullable|string|max:255',
            'supervisor_signature' => 'nullable|string|max:255',
            'supervisor_mobile' => 'nullable|string|max:255',
            // Legacy fields for backward compatibility
            'customer_name' => 'nullable|string|max:255',
            'contact_person' => 'nullable|string|max:255',
            'telephone' => 'nullable|string|max:255',
            'extension' => 'nullable|string|max:255',
            'fax' => 'nullable|string|max:255',
            'mobile' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'contract_period_days' => 'nullable|integer|min:1',
            'total_monthly_price' => 'nullable|numeric|min:0',
            'additional_trip_price' => 'nullable|numeric|min:0',
            'driver_id' => 'nullable|string|max:255',
        ]);

        $contract = $this->contractService->create($validated);

        return redirect()->route('contracts.show', $contract)
            ->with('success', 'Contract created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Contract $contract): View
    {
        $contract = $this->contractService->findById($contract->id);
        return view('contracts.show', compact('contract'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Contract $contract): View
    {
        $contract = $this->contractService->findById($contract->id);
        $statuses = $this->contractService->getStatuses();
        $customers = $this->contractService->getCustomers();
        $types = Type::all();
        return view('contracts.edit', compact('contract', 'statuses', 'customers', 'types'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Contract $contract): RedirectResponse
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'quotation_number' => 'nullable|string|max:255',
            'quotation_date' => 'nullable|date',
            'customer_name' => 'nullable|string|max:255',
            'contact_person' => 'nullable|string|max:255',
            'telephone' => 'nullable|string|max:255',
            'extension' => 'nullable|string|max:255',
            'fax' => 'nullable|string|max:255',
            'mobile' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'contract_period_days' => 'nullable|integer|min:1',
            'total_monthly_price' => 'nullable|numeric|min:0',
            'additional_trip_price' => 'nullable|numeric|min:0',
            'valid_until' => 'nullable|date',
            'status' => 'required|string',
            'notes' => 'nullable|string',
            'driver_id' => 'nullable|string|max:255',
            'agreement_terms' => 'nullable|string',
            'material_restrictions' => 'nullable|string',
            'delivery_terms' => 'nullable|string',
            'payment_policy' => 'nullable|string',
            'containers' => 'required|array|min:1',
            'containers.*.type_id' => 'required|exists:types,id',
            'containers.*.no_of_containers' => 'required|integer|min:1',
            'containers.*.monthly_dumping' => 'required|integer|min:0',
            'containers.*.price_per_container' => 'required|numeric|min:0',
            'containers.*.additional_trip_price' => 'nullable|numeric|min:0',
        ]);

        $this->contractService->update($contract, $validated);

        return redirect()->route('contracts.show', $contract)
            ->with('success', 'Contract updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Contract $contract): RedirectResponse
    {
        $this->contractService->delete($contract);

        return redirect()->route('contracts.index')
            ->with('success', 'Contract deleted successfully.');
    }

    /**
     * Download quotation PDF
     */
    public function downloadQuotation(Contract $contract)
    {
        return $this->contractService->downloadQuotationPdf($contract);
    }

    /**
     * Stream quotation PDF
     */
    public function streamQuotation(Contract $contract)
    {
        return $this->contractService->streamQuotationPdf($contract);
    }

    /**
     * Display quotation view
     */
    public function quotation(Contract $contract): View
    {
        $contract = $this->contractService->findById($contract->id);
        return view('contracts.quotation', compact('contract'));
    }

    /**
     * Get customer data for AJAX auto-fill
     */
    public function getCustomerData(Customer $customer): JsonResponse
    {
        return response()->json([
            'name' => $customer->name,
            'contact_person' => $customer->contact_person,
            'telephone' => $customer->telephone,
            'ext' => $customer->ext,
            'fax' => $customer->fax,
            'mobile' => $customer->mobile,
            'city' => $customer->city,
            'address' => $customer->address,
        ]);
    }

    /**
     * Calculate total price for AJAX
     */
    public function calculatePrice(Request $request): JsonResponse
    {
        $monthlyTotalDumpingCost = $request->input('dumping_cost', 0) * $request->input('no_containers', 0);
        $subtotal = $monthlyTotalDumpingCost + $request->input('additional_trip_cost', 0);
        $taxValue = $request->input('tax_value', 14);
        $taxAmount = $subtotal * ($taxValue / 100);
        $totalPrice = $subtotal + $taxAmount;

        return response()->json([
            'monthly_total_dumping_cost' => $monthlyTotalDumpingCost,
            'subtotal' => $subtotal,
            'tax_amount' => $taxAmount,
            'total_price' => $totalPrice,
        ]);
    }
}
