<?php

namespace App\Http\Controllers;

use App\Models\ContractContainerFill;
use App\Models\Contract;
use App\Models\Container;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class ContractContainerFillController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        $contractContainerFills = ContractContainerFill::with(['contract', 'container', 'client', 'deliver', 'discharge'])
            ->paginate(15);
        return view('contract_container_fills.index', compact('contractContainerFills'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        $contracts = Contract::all();
        $containers = Container::all();
        $customers = Customer::all();
        $users = User::all();
        return view('contract_container_fills.create', compact('contracts', 'containers', 'customers', 'users'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'contract_id' => 'required|exists:contracts,id',
            'no' => 'required|integer|min:1',
            'deliver_id' => 'nullable|exists:users,id',
            'deliver_at' => 'required|date',
            'container_id' => 'required|exists:containers,id',
            'expected_discharge_date' => 'required|date',
            'discharge_date' => 'nullable|date',
            'discharge_id' => 'nullable|exists:users,id',
            'price' => 'nullable|numeric|min:0',
            'client_id' => 'required|exists:customers,id',
            'city' => 'required|string|max:255',
            'address' => 'required|string',
            'notes' => 'nullable|string',
        ]);

        ContractContainerFill::create($validated);

        return redirect()->route('contract-container-fills.index')
            ->with('success', 'Contract Container Fill created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(ContractContainerFill $contractContainerFill): View
    {
        $contractContainerFill->load(['contract', 'container', 'client', 'deliver', 'discharge']);
        return view('contract_container_fills.show', compact('contractContainerFill'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ContractContainerFill $contractContainerFill): View
    {
        $contracts = Contract::all();
        $containers = Container::all();
        $customers = Customer::all();
        $users = User::all();
        return view('contract_container_fills.edit', compact('contractContainerFill', 'contracts', 'containers', 'customers', 'users'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ContractContainerFill $contractContainerFill): RedirectResponse
    {
        $validated = $request->validate([
            'contract_id' => 'required|exists:contracts,id',
            'no' => 'required|integer|min:1',
            'deliver_id' => 'nullable|exists:users,id',
            'deliver_at' => 'required|date',
            'container_id' => 'required|exists:containers,id',
            'expected_discharge_date' => 'required|date',
            'discharge_date' => 'nullable|date',
            'discharge_id' => 'nullable|exists:users,id',
            'price' => 'nullable|numeric|min:0',
            'client_id' => 'required|exists:customers,id',
            'city' => 'required|string|max:255',
            'address' => 'required|string',
            'notes' => 'nullable|string',
        ]);

        $contractContainerFill->update($validated);

        return redirect()->route('contract-container-fills.show', $contractContainerFill)
            ->with('success', 'Contract Container Fill updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ContractContainerFill $contractContainerFill): RedirectResponse
    {
        $contractContainerFill->delete();

        return redirect()->route('contract-container-fills.index')
            ->with('success', 'Contract Container Fill deleted successfully.');
    }
}
