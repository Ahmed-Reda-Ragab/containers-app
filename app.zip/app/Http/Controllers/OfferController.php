<?php

namespace App\Http\Controllers;

use App\Models\Offer;
use App\Services\OfferService;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class OfferController extends Controller
{
    protected OfferService $offerService;

    public function __construct(OfferService $offerService)
    {
        $this->offerService = $offerService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        $offers = $this->offerService->getAll();
        return view('offers.index', compact('offers'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        $statuses = $this->offerService->getStatuses();
        $customers = $this->offerService->getCustomers();
        $containers = $this->offerService->getContainers();
        $offerNumber = $this->offerService->generateOfferNumber();
        return view('offers.create', compact('statuses', 'customers', 'containers', 'offerNumber'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'offer_number' => 'required|string|unique:offers,offer_number',
            'offer_date' => 'required|date',
            'valid_until' => 'required|date|after:offer_date',
            'customer_name' => 'required|string|max:255',
            'contact_person' => 'nullable|string|max:255',
            'telephone' => 'nullable|string|max:255',
            'extension' => 'nullable|string|max:255',
            'fax' => 'nullable|string|max:255',
            'mobile' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'contract_period_days' => 'required|integer|min:1',
            'additional_trip_price' => 'required|numeric|min:0',
            'status' => 'required|string',
            'notes' => 'nullable|string',
            'agreement_terms' => 'nullable|string',
            'material_restrictions' => 'nullable|string',
            'delivery_terms' => 'nullable|string',
            'payment_policy' => 'nullable|string',
            'containers' => 'required|array|min:1',
            'containers.*.container_id' => 'required|exists:containers,id',
            'containers.*.no_of_containers' => 'required|integer|min:1',
            'containers.*.monthly_dumping_per_container' => 'required|integer|min:0',
            'containers.*.price_per_container' => 'required|numeric|min:0',
        ]);

        $offer = $this->offerService->create($validated);

        return redirect()->route('offers.show', $offer)
            ->with('success', 'Offer created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Offer $offer): View
    {
        $offer = $this->offerService->findById($offer->id);
        return view('offers.show', compact('offer'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Offer $offer): View
    {
        $offer = $this->offerService->findById($offer->id);
        $statuses = $this->offerService->getStatuses();
        $customers = $this->offerService->getCustomers();
        $containers = $this->offerService->getContainers();
        return view('offers.edit', compact('offer', 'statuses', 'customers', 'containers'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Offer $offer): RedirectResponse
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'offer_number' => 'required|string|unique:offers,offer_number,' . $offer->id,
            'offer_date' => 'required|date',
            'valid_until' => 'required|date|after:offer_date',
            'customer_name' => 'required|string|max:255',
            'contact_person' => 'nullable|string|max:255',
            'telephone' => 'nullable|string|max:255',
            'extension' => 'nullable|string|max:255',
            'fax' => 'nullable|string|max:255',
            'mobile' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'contract_period_days' => 'required|integer|min:1',
            'additional_trip_price' => 'required|numeric|min:0',
            'status' => 'required|string',
            'notes' => 'nullable|string',
            'agreement_terms' => 'nullable|string',
            'material_restrictions' => 'nullable|string',
            'delivery_terms' => 'nullable|string',
            'payment_policy' => 'nullable|string',
            'containers' => 'required|array|min:1',
            'containers.*.container_id' => 'required|exists:containers,id',
            'containers.*.no_of_containers' => 'required|integer|min:1',
            'containers.*.monthly_dumping_per_container' => 'required|integer|min:0',
            'containers.*.price_per_container' => 'required|numeric|min:0',
        ]);

        $this->offerService->update($offer, $validated);

        return redirect()->route('offers.show', $offer)
            ->with('success', 'Offer updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Offer $offer): RedirectResponse
    {
        $this->offerService->delete($offer);

        return redirect()->route('offers.index')
            ->with('success', 'Offer deleted successfully.');
    }

    /**
     * Download offer PDF
     */
    public function downloadOffer(Offer $offer)
    {
        return $this->offerService->downloadOfferPdf($offer);
    }

    /**
     * Stream offer PDF
     */
    public function streamOffer(Offer $offer)
    {
        return $this->offerService->streamOfferPdf($offer);
    }
}
