<?php

return [
    'container' => [
        'available' => 'متاح',
        'in_use' => 'قيد الاستخدام',
        'filled' => 'ممتلئ',
        'maintenance' => 'صيانة',
        'out_of_service' => 'خارج الخدمة',
    ],
];