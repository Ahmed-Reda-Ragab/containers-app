<?php

return [
    'container' => [
        'available' => 'Available',
        'in_use' => 'In Use',
        'filled' => 'Filled',
        'maintenance' => 'Maintenance',
        'out_of_service' => 'Out of Service',
    ],
];
