<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ __('Dumpster Rental Quotation') }} - {{ $contract->quotation_number ?? $contract->id }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .quotation-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            color: #333;
            font-size: 24px;
        }
        .header h2 {
            margin: 5px 0;
            color: #666;
            font-size: 18px;
        }
        .quotation-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }
        .quotation-info div {
            flex: 1;
        }
        .quotation-info .right {
            text-align: right;
        }
        .quotation-number {
            color: #d32f2f;
            font-weight: bold;
            font-size: 18px;
        }
        .section {
            margin-bottom: 25px;
        }
        .section-header {
            background-color: #333;
            color: white;
            padding: 10px 15px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .section-content {
            padding: 15px;
            background-color: #f9f9f9;
        }
        .form-row {
            display: flex;
            margin-bottom: 10px;
        }
        .form-row .label {
            width: 200px;
            font-weight: bold;
            color: #333;
        }
        .form-row .value {
            flex: 1;
            color: #666;
        }
        .form-row .arabic {
            width: 200px;
            text-align: right;
            color: #333;
            font-weight: bold;
        }
        .service-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .service-table th,
        .service-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .service-table th {
            background-color: #333;
            color: white;
            font-weight: bold;
        }
        .service-table .value-column {
            width: 80px;
            text-align: center;
            font-weight: bold;
        }
        .service-table .unit-column {
            width: 100px;
            text-align: center;
        }
        .service-table .arabic-column {
            width: 200px;
            text-align: right;
        }
        .total-row {
            background-color: #f0f0f0;
            font-weight: bold;
        }
        .terms-section {
            margin-top: 30px;
        }
        .terms-content {
            background-color: #f9f9f9;
            padding: 15px;
            border-left: 4px solid #333;
        }
        .signature-section {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        .signature-box {
            width: 45%;
            border: 1px solid #ddd;
            padding: 15px;
        }
        .signature-box h4 {
            margin: 0 0 15px 0;
            color: #333;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
        }
        .signature-field {
            margin-bottom: 20px;
        }
        .signature-field label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }
        .signature-field .value {
            border-bottom: 1px solid #333;
            padding: 5px 0;
            min-height: 20px;
        }
        .expiry-date {
            text-align: center;
            margin: 20px 0;
            font-weight: bold;
            color: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="quotation-container">
        <!-- Header -->
        <div class="header">
            <h1>{{ __('Dumpster Rental Quotation') }}</h1>
            <h2>عرض تأجير حاويات</h2>
        </div>

        <!-- Quotation Info -->
        <div class="quotation-info">
            <div class="left">
                <div class="form-row">
                    <div class="label">{{ __('Date') }} / التاريخ:</div>
                    <div class="value">{{ $contract->quotation_date ? $contract->quotation_date->format('Y-m-d') : now()->format('Y-m-d') }}</div>
                </div>
            </div>
            <div class="right">
                <div class="quotation-number">
                    {{ __('Quotation No') }} / رقم العرض: {{ $contract->quotation_number ?? $contract->id }}
                </div>
            </div>
        </div>

        <!-- Customer Information -->
        <div class="section">
            <div class="section-header">
                {{ __('Customer Information') }} / معلومات العميل
            </div>
            <div class="section-content">
                <div class="form-row">
                    <div class="label">{{ __('Customer Name') }} / اسم العميل:</div>
                    <div class="value">{{ $contract->customer_name ?? $contract->customer->name }}</div>
                    <div class="arabic">اسم العميل</div>
                </div>
                <div class="form-row">
                    <div class="label">{{ __('Contact Person') }} / المسئول:</div>
                    <div class="value">{{ $contract->contact_person ?? '-' }}</div>
                    <div class="arabic">المسئول</div>
                </div>
                <div class="form-row">
                    <div class="label">{{ __('Telephone') }} / الهاتف:</div>
                    <div class="value">{{ $contract->telephone ?? '0' }}</div>
                    <div class="arabic">الهاتف</div>
                </div>
                <div class="form-row">
                    <div class="label">{{ __('Ext') }} / تحويله:</div>
                    <div class="value">{{ $contract->extension ?? '0' }}</div>
                    <div class="arabic">تحويله</div>
                </div>
                <div class="form-row">
                    <div class="label">{{ __('FAX') }} / الفاكس:</div>
                    <div class="value">{{ $contract->fax ?? '0' }}</div>
                    <div class="arabic">الفاكس</div>
                </div>
                <div class="form-row">
                    <div class="label">{{ __('Mobile') }} / الجوال:</div>
                    <div class="value">{{ $contract->mobile ?? '0000000000' }}</div>
                    <div class="arabic">الجوال</div>
                </div>
                <div class="form-row">
                    <div class="label">{{ __('City') }} / المدينة:</div>
                    <div class="value">{{ $contract->city ?? 'DAMMAM' }}</div>
                    <div class="arabic">الدمام</div>
                </div>
                <div class="form-row">
                    <div class="label">{{ __('Address') }} / العنوان:</div>
                    <div class="value">{{ $contract->address ?? '-' }}</div>
                    <div class="arabic">العنوان</div>
                </div>
            </div>
        </div>

        <!-- Service Details -->
        <div class="section">
            <div class="section-header">
                {{ __('Service Details') }} / تفاصيل الخدمة
            </div>
            <div class="section-content">
                <table class="service-table">
                    <thead>
                        <tr>
                            <th>{{ __('Description') }}</th>
                            <th class="value-column">{{ __('Value') }}</th>
                            <th class="unit-column">{{ __('Unit') }}</th>
                            <th class="arabic-column">{{ __('Arabic') }}</th>
                            <th class="unit-column">{{ __('Unit') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($contract->contractContainers as $index => $contractContainer)
                        <tr>
                            <td>{{ __('Container Size') }} / حجم الحاوية</td>
                            <td class="value-column">{{ $contractContainer->type->name ?? '12' }}</td>
                            <td class="unit-column">{{ __('Yards') }}</td>
                            <td class="arabic-column">حجم الحاوية</td>
                            <td class="unit-column">ياردة</td>
                        </tr>
                        <tr>
                            <td>{{ __('Price/Container') }} / السعر/حاوية</td>
                            <td class="value-column">{{ number_format($contractContainer->price_per_container, 0) }}</td>
                            <td class="unit-column">{{ __('SAR') }}</td>
                            <td class="arabic-column">السعر/حاوية</td>
                            <td class="unit-column">ريال</td>
                        </tr>
                        <tr>
                            <td>{{ __('No. of Containers') }} / عدد الحاويات</td>
                            <td class="value-column">{{ $contractContainer->no_of_containers }}</td>
                            <td class="unit-column">{{ __('Container') }}</td>
                            <td class="arabic-column">عدد الحاويات</td>
                            <td class="unit-column">حاوية</td>
                        </tr>
                        <tr>
                            <td>{{ __('Monthly Dumping/Cont.') }} / عدد التفريغ الشهري/حاوية</td>
                            <td class="value-column">{{ $contractContainer->monthly_dumping }}</td>
                            <td class="unit-column">{{ __('Container') }}</td>
                            <td class="arabic-column">عدد التفريغ الشهري/حاوية</td>
                            <td class="unit-column">حاوية</td>
                        </tr>
                        <tr>
                            <td>{{ __('Total Dumping') }} / إجمالي عدد التفريغ الشهري</td>
                            <td class="value-column">{{ $contractContainer->monthly_dumping * $contractContainer->no_of_containers }}</td>
                            <td class="unit-column">{{ __('Container') }}</td>
                            <td class="arabic-column">إجمالي عدد التفريغ الشهري</td>
                            <td class="unit-column">حاوية</td>
                        </tr>
                        <tr>
                            <td>{{ __('Total Monthly Price') }} / إجمالي الاتفاقية الشهرية</td>
                            <td class="value-column">{{ number_format($contractContainer->no_of_containers * $contractContainer->price_per_container, 0) }}</td>
                            <td class="unit-column">{{ __('SAR') }}</td>
                            <td class="arabic-column">إجمالي الاتفاقية الشهرية</td>
                            <td class="unit-column">ريال</td>
                        </tr>
                        @if($index === 0)
                        <tr>
                            <td>{{ __('Additional Trips') }} / الرفع الإضافي</td>
                            <td class="value-column">{{ number_format($contract->additional_trip_price ?? 250, 0) }}</td>
                            <td class="unit-column">{{ __('SAR') }}</td>
                            <td class="arabic-column">الرفع الإضافي</td>
                            <td class="unit-column">ريال</td>
                        </tr>
                        <tr>
                            <td>{{ __('Contract Period') }} / مدة إيجار الحاوية الواحدة</td>
                            <td class="value-column">{{ $contract->contract_period_days }}</td>
                            <td class="unit-column">{{ __('Days') }}</td>
                            <td class="arabic-column">مدة إيجار الحاوية الواحدة</td>
                            <td class="unit-column">يوم</td>
                        </tr>
                        <tr class="total-row">
                            <td>{{ __('Total Price') }} / إجمالي الاتفاقية الشهرية</td>
                            <td class="value-column">{{ number_format($contract->total_price, 0) }}</td>
                            <td class="unit-column">{{ __('SAR') }}</td>
                            <td class="arabic-column">إجمالي الاتفاقية الشهرية</td>
                            <td class="unit-column">ريال</td>
                        </tr>
                        @endif
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Expiry Date -->
        <div class="expiry-date">
            {{ __('Offer Expires On') }} ينتهي العرض في تاريخ: {{ $contract->valid_until ? $contract->valid_until->format('Y/m/d') : now()->addDays(30)->format('Y/m/d') }}
        </div>

        <!-- Terms and Conditions -->
        <div class="terms-section">
            <div class="section">
                <div class="section-header">
                    {{ __('Agreement') }} / الالتزام
                </div>
                <div class="terms-content">
                    <p>{{ $contract->agreement_terms ?? __('Rtm Arabia EST. agree to provide the disposal services and/or equipments specified herein and customer agrees to make the payment as provided for herein and abide by the terms and conditions of this agreement.') }}</p>
                </div>
            </div>

            <div class="section">
                <div class="section-header">
                    {{ __('Material') }} / مواد المخلفات
                </div>
                <div class="terms-content">
                    <p>{{ $contract->material_restrictions ?? __('Material that will be collected and disposed by Rtm Arabia EST. is solid material generated by customer excluding radioactive, volatile, highly flammable, explosive, toxic or hazardous material.') }}</p>
                </div>
            </div>

            <div class="section">
                <div class="section-header">
                    {{ __('Receiving Containers') }} / استلام الحاويات
                </div>
                <div class="terms-content">
                    <p>{{ $contract->delivery_terms ?? __('Any delivered container shall come with service delivery note/receipt even additional trips. Note: 1- Container will be delivered when requested by customer. 2-Customer is entitled to request the container within six months from the date of the contract.') }}</p>
                </div>
            </div>

            <div class="section">
                <div class="section-header">
                    {{ __('Payments Policy') }} / سياسة سداد المستحقات
                </div>
                <div class="terms-content">
                    <p>{{ $contract->payment_policy ?? __('The amount due will be paid immediately from the date of issue of the invoice according to the agreement between the customer and RTM') }}</p>
                </div>
            </div>
        </div>

        <!-- Signatures -->
        <div class="signature-section">
            <div class="signature-box">
                <h4>{{ __('RTM Arabia Est') }} / مؤسسة رتم العربية للتأجير</h4>
                <div class="signature-field">
                    <label>{{ __('Manager Name') }} / اسم المسئول:</label>
                    <div class="value">Rakan M Al-Marzuqi / راكان منصور المرزوقي</div>
                </div>
                <div class="signature-field">
                    <label>{{ __('Signature') }} / التوقيع:</label>
                    <div class="value" style="height: 40px;"></div>
                </div>
                <div class="signature-field">
                    <label>{{ __('Date') }} / التاريخ:</label>
                    <div class="value">{{ now()->format('Y/m/d') }}</div>
                </div>
            </div>

            <div class="signature-box">
                <h4>{{ __('Customer Information') }} / معلومات العميل</h4>
                <div class="signature-field">
                    <label>{{ __('Name') }} / الاسم:</label>
                    <div class="value">{{ $contract->customer_name ?? $contract->customer->name }}</div>
                </div>
                <div class="signature-field">
                    <label>{{ __('Signature') }} / التوقيع:</label>
                    <div class="value" style="height: 40px;"></div>
                </div>
                <div class="signature-field">
                    <label>{{ __('Date') }} / التاريخ:</label>
                    <div class="value"></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
