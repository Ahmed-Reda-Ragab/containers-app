@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Contract Header -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Dumpster Rental Contract</h4>
                    <div class="btn-group" role="group">
                        <a href="{{ route('contracts.quotation', $contract) }}" class="btn btn-outline-primary" target="_blank">
                            <i class="fas fa-file-pdf"></i> View Quotation
                        </a>
                        <a href="{{ route('contracts.edit', $contract) }}" class="btn btn-outline-secondary">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="{{ route('contracts.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Contracts
                        </a>
                    </div>
                </div>
            </div>

            <!-- Company Header -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="d-flex align-items-center mb-3">
                                @if($contract->company_logo)
                                    <img src="{{ $contract->company_logo }}" alt="Company Logo" class="me-3" style="height: 60px;">
                                @endif
                                <div>
                                    <h3 class="mb-0">{{ $contract->company_name ?? 'Support Lines Company' }}</h3>
                                    <p class="text-muted mb-0">شركة خطوط الإسناد</p>
                                    <small class="text-muted">Services & General Contracting</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 text-end">
                            <h4 class="mb-0">Dumpster Rental Quotation</h4>
                            <p class="text-muted mb-0">عرض تاجير حاويات</p>
                            <div class="mt-2">
                                <strong>Quotation No:</strong> {{ $contract->quotation_number ?? 'CR. ' . str_pad($contract->id, 10, '0', STR_PAD_LEFT) }}<br>
                                <strong>Date:</strong> {{ $contract->quotation_date ? $contract->quotation_date->format('d/m/Y') : $contract->created_at->format('d/m/Y') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Customer Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Customer Information / معلومات العميل</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Company Name:</strong></td>
                                    <td>{{ $contract->customer_details['company_name'] ?? $contract->customer->name ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Contact Person:</strong></td>
                                    <td>{{ $contract->customer_details['contact_person'] ?? $contract->contact_person ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Telephone:</strong></td>
                                    <td>{{ $contract->customer_details['telephone'] ?? $contract->telephone ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Ext:</strong></td>
                                    <td>{{ $contract->customer_details['ext'] ?? $contract->extension ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>FAX:</strong></td>
                                    <td>{{ $contract->customer_details['fax'] ?? $contract->fax ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Mobile:</strong></td>
                                    <td>{{ $contract->customer_details['mobile'] ?? $contract->mobile ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>City:</strong></td>
                                    <td>{{ $contract->customer_details['city'] ?? $contract->city ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Address:</strong></td>
                                    <td>{{ $contract->customer_details['address'] ?? $contract->address ?? 'N/A' }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>اسم الشركة:</strong></td>
                                    <td>{{ $contract->customer_details['company_name_ar'] ?? 'مؤسسة حسين محمد رضوان التجارية' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>السيد:</strong></td>
                                    <td>{{ $contract->customer_details['contact_person_ar'] ?? 'احمد' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>الهاتف:</strong></td>
                                    <td>{{ $contract->customer_details['telephone_ar'] ?? '0' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>تحويله:</strong></td>
                                    <td>{{ $contract->customer_details['ext_ar'] ?? '0' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>الفاكس:</strong></td>
                                    <td>{{ $contract->customer_details['fax_ar'] ?? '0' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>الجوال:</strong></td>
                                    <td>{{ $contract->customer_details['mobile_ar'] ?? '0581262826' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>المدينة:</strong></td>
                                    <td>{{ $contract->customer_details['city_ar'] ?? 'الدمام' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>الحي:</strong></td>
                                    <td>{{ $contract->customer_details['address_ar'] ?? '0' }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Service Details -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Service Details / تفاصيل الخدمة</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>Container Size / حجم الحاوية</th>
                                    <th>Price/Container / سعر الحاوية</th>
                                    <th>No. of Containers / عدد الحاويات</th>
                                    <th>Monthly Dumping/Cont. / التفريغ الشهري</th>
                                    <th>Total Dumping / إجمالي التفريغ</th>
                                    <th>Additional Trips / رحلات إضافية</th>
                                    <th>Contract Period / مدة العقد</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{{ $contract->container_size ?? '12 Yards' }} / {{ $contract->container_size_ar ?? '12 ياردة' }}</td>
                                    <td>{{ number_format($contract->price_per_container ?? 250, 0) }} SAR / {{ number_format($contract->price_per_container ?? 250, 0) }} ريال</td>
                                    <td>{{ $contract->no_of_containers ?? 1 }} Container / {{ $contract->no_of_containers ?? 1 }} حاوية</td>
                                    <td>{{ $contract->monthly_dumping_per_container ?? 2 }} Container / {{ $contract->monthly_dumping_per_container ?? 2 }} حاوية</td>
                                    <td>{{ $contract->total_dumping ?? 2 }} Container / {{ $contract->total_dumping ?? 2 }} حاوية</td>
                                    <td>{{ number_format($contract->additional_trips_price ?? 250, 0) }} SAR / {{ number_format($contract->additional_trips_price ?? 250, 0) }} ريال</td>
                                    <td>{{ $contract->contract_period_months ?? 12 }} Months / {{ $contract->contract_period_months ?? 12 }} شهر</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <div class="alert alert-info">
                                <strong>Total Monthly Price:</strong> {{ number_format($contract->total_monthly_price ?? 500, 0) }} SAR<br>
                                <strong>Total monthly agreement including value added tax ({{ $contract->tax_value ?? 15 }}%):</strong> {{ number_format($contract->total_monthly_with_tax ?? 575, 2) }} SAR<br>
                                <strong>Total yearly agreement including value added tax ({{ $contract->tax_value ?? 15 }}%):</strong> {{ number_format($contract->total_yearly_with_tax ?? 6900, 0) }} SAR
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="alert alert-info text-end" dir="rtl">
                                <strong>إجمالي السعر الشهري:</strong> {{ number_format($contract->total_monthly_price ?? 500, 0) }} ريال<br>
                                <strong>إجمالي الاتفاقية الشهرية شاملة ضريبة القيمة المضافة ({{ $contract->tax_value ?? 15 }}%):</strong> {{ number_format($contract->total_monthly_with_tax ?? 575, 2) }} ريال<br>
                                <strong>إجمالي الاتفاقية السنوية شاملة ضريبة القيمة المضافة ({{ $contract->tax_value ?? 15 }}%):</strong> {{ number_format($contract->total_yearly_with_tax ?? 6900, 0) }} ريال
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Terms and Conditions -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Terms and Conditions / الشروط والأحكام</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Agreement / الالتزام</h6>
                            <p>{{ $contract->agreement_terms_ar ?? 'Support Lines Co. will provide disposal services and equipment, and the customer agrees to payment and terms.' }}</p>
                            
                            <h6>Material / مواد المخلفات</h6>
                            <p>{{ $contract->material_restrictions_ar ?? 'Collected material is solid, excluding radioactive, volatile, flammable, explosive, toxic, damaged tires, or hazardous materials.' }}</p>
                            
                            <h6>Receiving Containers / استلام الحاويات</h6>
                            <p>{{ $contract->receiving_terms_ar ?? 'Any delivered container will come with a service delivery note/receipt.' }}</p>
                            
                            <h6>Notes / ملاحظة</h6>
                            <p>{{ $contract->notes_ar ?? '1. Offer is valid for 30 days from the date of the offer. 2. Prices are subject to change after the specified period.' }}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>الالتزام</h6>
                            <p>{{ $contract->agreement_terms_ar ?? 'شركة خطوط الإسناد ستوفر خدمات التخلص والمعدات، والعميل يوافق على الدفع والشروط.' }}</p>
                            
                            <h6>مواد المخلفات</h6>
                            <p>{{ $contract->material_restrictions_ar ?? 'المواد المجمعة صلبة، باستثناء المواد المشعة، المتطايرة، القابلة للاشتعال، المتفجرة، السامة، الإطارات التالفة، أو المواد الخطرة.' }}</p>
                            
                            <h6>استلام الحاويات</h6>
                            <p>{{ $contract->receiving_terms_ar ?? 'أي حاوية يتم تسليمها ستأتي مع إيصال/إشعار تسليم الخدمة.' }}</p>
                            
                            <h6>ملاحظة</h6>
                            <p>{{ $contract->notes_ar ?? '1. العرض صالح لمدة 30 يوماً من تاريخ العرض. 2. الأسعار قابلة للتغيير بعد الفترة المحددة.' }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment History -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Payment History / تاريخ المدفوعات</h5>
                </div>
                <div class="card-body">
                    @if($contract->payments->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>User</th>
                                        <th>Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($contract->payments as $payment)
                                        <tr>
                                            <td>{{ $payment->created_at->format('Y-m-d H:i') }}</td>
                                            <td>${{ number_format($payment->payed, 2) }}</td>
                                            <td>{{ $payment->user->name ?? 'N/A' }}</td>
                                            <td>{{ $payment->notes ?? '-' }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <strong>Total Paid:</strong> ${{ number_format($contract->payments->sum('payed'), 2) }} / 
                            <strong>Remaining:</strong> ${{ number_format($contract->total_price - $contract->payments->sum('payed'), 2) }}
                        </div>
                    @else
                        <p class="text-muted">No payments recorded yet.</p>
                    @endif
                </div>
            </div>

            <!-- Container History -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Container History / تاريخ الحاويات</h5>
                </div>
                <div class="card-body">
                    @if($contract->contractContainerFills->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Container</th>
                                        <th>Deliver Date</th>
                                        <th>Expected Discharge</th>
                                        <th>Discharge Date</th>
                                        <th>Status</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($contract->contractContainerFills as $fill)
                                        <tr>
                                            <td>{{ $fill->container->code ?? 'N/A' }}</td>
                                            <td>{{ $fill->deliver_at->format('Y-m-d') }}</td>
                                            <td>{{ $fill->expected_discharge_date->format('Y-m-d') }}</td>
                                            <td>{{ $fill->discharge_date ? $fill->discharge_date->format('Y-m-d') : 'Not discharged' }}</td>
                                            <td>
                                                <span class="badge bg-{{ $fill->discharge_date ? 'success' : 'warning' }}">
                                                    {{ $fill->discharge_date ? 'Discharged' : 'Pending' }}
                                                </span>
                                            </td>
                                            <td>{{ $fill->price ? '$' . number_format($fill->price, 2) : 'N/A' }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <p class="text-muted">No container deliveries recorded yet.</p>
                    @endif
                </div>
            </div>

            <!-- Signatures -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Signatures / التوقيعات</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Support Lines Company / شركة خطوط الإسناد</h6>
                            <p><strong>Manager Name:</strong> {{ $contract->manager_name ?? 'Rakan M Al-Marzugi' }}</p>
                            <p><strong>Date:</strong> {{ $contract->quotation_date ? $contract->quotation_date->format('d/m/Y') : now()->format('d/m/Y') }}</p>
                            @if($contract->manager_signature)
                                <img src="{{ $contract->manager_signature }}" alt="Manager Signature" style="max-height: 100px;">
                            @endif
                        </div>
                        <div class="col-md-6">
                            <h6>Marketing and Sales Department / قسم التسويق والمبيعات</h6>
                            <p><strong>Supervisor:</strong> {{ $contract->supervisor_name ?? 'N/A' }}</p>
                            <p><strong>Mobile:</strong> {{ $contract->supervisor_mobile ?? '0559060303' }}</p>
                            @if($contract->supervisor_signature)
                                <img src="{{ $contract->supervisor_signature }}" alt="Supervisor Signature" style="max-height: 100px;">
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <!-- Company Contact Information -->
            <div class="card">
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-12">
                            <h6>Contact Information / معلومات الاتصال</h6>
                            <p>
                                <strong>Office:</strong> {{ $contract->company_phone ?? '(966) 13 8060303' }} | 
                                <strong>Mob:</strong> {{ $contract->supervisor_mobile ?? '(966) 559060303' }} | 
                                <strong>C.C. No:</strong> 140977 | 
                                <strong>Website:</strong> {{ $contract->company_website ?? 'support-lines.com' }} | 
                                <strong>Email:</strong> {{ $contract->company_email ?? 'info@support-lines.com' }} | 
                                <strong>P.O. Box:</strong> {{ $contract->company_pobox ?? '6410 Dammam 32272 KSA' }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
@endsection