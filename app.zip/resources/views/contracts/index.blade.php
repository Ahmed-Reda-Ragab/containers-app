@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">{{ __('Contracts Management') }}</h4>
                    <a href="{{ route('contracts.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i> {{ __('Add New Contract') }}
                    </a>
                </div>

                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @if($contracts->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>{{ __('ID') }}</th>
                                        <th>{{ __('Customer') }}</th>
                                        <th>{{ __('Start Date') }}</th>
                                        <th>{{ __('End Date') }}</th>
                                        <th>{{ __('Period') }}</th>
                                        <th>{{ __('Total Price') }}</th>
                                        <th>{{ __('Status') }}</th>
                                        <th>{{ __('Actions') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($contracts as $contract)
                                        <tr>
                                            <td>{{ $contract->id }}</td>
                                            <td>
                                                <strong>{{ $contract->customer->name }}</strong>
                                                @if($contract->customer->company_name)
                                                    <br><small class="text-muted">{{ $contract->customer->company_name }}</small>
                                                @endif
                                            </td>
                                            <td>{{ $contract->start_date->format('M d, Y') }}</td>
                                            <td>{{ $contract->end_date->format('M d, Y') }}</td>
                                            <td>{{ $contract->contract_period_days }} days</td>
                                            <td>
                                                <strong class="text-success">${{ number_format($contract->total_price, 2) }}</strong>
                                            </td>
                                            <td>
                                                @php
                                                    $statusClass = match($contract->status->value) {
                                                        'active' => 'success',
                                                        'expired' => 'warning',
                                                        'canceled' => 'danger',
                                                        default => 'secondary'
                                                    };
                                                @endphp
                                                <span class="badge bg-{{ $statusClass }}">{{ $contract->status->label() }}</span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="{{ route('contracts.show', $contract) }}" class="btn btn-sm btn-outline-info" title="{{ __('View') }}">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="{{ route('contracts.edit', $contract) }}" class="btn btn-sm btn-outline-warning" title="{{ __('Edit') }}">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="{{ route('contracts.quotation.download', $contract) }}" class="btn btn-sm btn-outline-primary" title="{{ __('Download Quotation') }}">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <form action="{{ route('contracts.destroy', $contract) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Are you sure you want to delete this contract?') }}')">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="{{ __('Delete') }}">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-center">
                            {{ $contracts->links() }}
                        </div>
                    @else
                        <div class="text-center py-5">
                            <i class="fas fa-file-contract fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">{{ __('No contracts found') }}</h5>
                            <p class="text-muted">{{ __('Get started by creating your first contract.') }}</p>
                            <a href="{{ route('contracts.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> {{ __('Add New Contract') }}
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
@endsection
