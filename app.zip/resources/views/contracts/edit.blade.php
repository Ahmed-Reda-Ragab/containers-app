@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Edit Contract #{{ $contract->id }}</h4>
                    <a href="{{ route('contracts.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Contracts
                    </a>
                </div>

                <div class="card-body">
                    <form action="{{ route('contracts.update', $contract) }}" method="POST" id="contractForm">
                        @csrf
                        @method('PUT')

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="customer_id" class="form-label">Customer <span class="text-danger">*</span></label>
                                <select class="form-select @error('customer_id') is-invalid @enderror"
                                        id="customer_id" name="customer_id" required>
                                    <option value="">Select Customer</option>
                                    @foreach($customers as $customer)
                                        <option value="{{ $customer->id }}" {{ old('customer_id', $contract->customer_id) == $customer->id ? 'selected' : '' }}>
                                            {{ $customer->name }} @if($customer->company_name) - {{ $customer->company_name }} @endif
                                        </option>
                                    @endforeach
                                </select>
                                @error('customer_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                <select class="form-select @error('status') is-invalid @enderror"
                                        id="status" name="status" required>
                                    <option value="">Select Status</option>
                                    @foreach($statuses as $key => $label)
                                        <option value="{{ $key }}" {{ old('status', $contract->status->value) == $key ? 'selected' : '' }}>
                                            {{ $label }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('status')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="start_date" class="form-label">Start Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('start_date') is-invalid @enderror"
                                       id="start_date" name="start_date" value="{{ old('start_date', $contract->start_date->format('Y-m-d')) }}" required>
                                @error('start_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="end_date" class="form-label">End Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('end_date') is-invalid @enderror"
                                       id="end_date" name="end_date" value="{{ old('end_date', $contract->end_date->format('Y-m-d')) }}" required>
                                @error('end_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="driver_id" class="form-label">{{ __('Driver ID') }}</label>
                                <input type="text" class="form-control @error('driver_id') is-invalid @enderror"
                                       id="driver_id" name="driver_id" value="{{ old('driver_id', $contract->driver_id) }}"
                                       placeholder="Enter driver ID (optional)">
                                @error('driver_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="notes" class="form-label">{{ __('Notes') }}</label>
                                <textarea class="form-control @error('notes') is-invalid @enderror"
                                          id="notes" name="notes" rows="3"
                                          placeholder="{{ __('Enter contract notes (optional)') }}">{{ old('notes', $contract->notes) }}</textarea>
                                @error('notes')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5>Container Details</h5>
                            <button type="button" class="btn btn-success btn-sm" id="addContainer">
                                <i class="fas fa-plus"></i> Add Container
                            </button>
                        </div>

                        <div id="containersContainer">
                            @foreach($contract->contractContainers as $index => $contractContainer)
                                <div class="container-item border rounded p-3 mb-3">
                                    <div class="row">
                                        <div class="col-md-3 mb-3">
                                            <label class="form-label">Container <span class="text-danger">*</span></label>
                                            <select class="form-select container-select" name="containers[{{ $index }}][container_id]" required>
                                                <option value="">Select Container</option>
                                                @foreach($containers as $container)
                                                    <option value="{{ $container->id }}" {{ $contractContainer->container_id == $container->id ? 'selected' : '' }}>
                                                        {{ $container->code }} - {{ ucfirst(str_replace('_', ' ', $container->type)) }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Quantity <span class="text-danger">*</span></label>
                                            <input type="number" class="form-control" name="containers[{{ $index }}][no_of_containers]"
                                                   min="1" value="{{ $contractContainer->no_of_containers }}" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Monthly Dumping <span class="text-danger">*</span></label>
                                            <input type="number" class="form-control" name="containers[{{ $index }}][monthly_dumping]"
                                                   min="0" value="{{ $contractContainer->monthly_dumping }}" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Price per Container <span class="text-danger">*</span></label>
                                            <input type="number" class="form-control price-input" name="containers[{{ $index }}][price_per_container]"
                                                   step="0.01" min="0" value="{{ $contractContainer->price_per_container }}" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Additional Trip Price</label>
                                            <input type="number" class="form-control" name="containers[{{ $index }}][additional_trip_price]"
                                                   step="0.01" min="0" value="{{ $contractContainer->additional_trip_price }}">
                                        </div>
                                        <div class="col-md-1 mb-3">
                                            <label class="form-label">&nbsp;</label>
                                            <button type="button" class="btn btn-danger btn-sm w-100 remove-container">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <div class="alert alert-info">
                            <strong>Total Contract Value: $<span id="totalValue">{{ number_format($contract->total_price, 2) }}</span></strong>
                        </div>

                        <div class="d-flex justify-content-end gap-2">
                            <a href="{{ route('contracts.show', $contract) }}" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Contract
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<script>
document.addEventListener('DOMContentLoaded', function() {
    let containerIndex = {{ $contract->contractContainers->count() }};
    const containersContainer = document.getElementById('containersContainer');
    const addContainerBtn = document.getElementById('addContainer');
    const totalValueSpan = document.getElementById('totalValue');

    // Add container functionality
    addContainerBtn.addEventListener('click', function() {
        const containerHtml = `
            <div class="container-item border rounded p-3 mb-3">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Container <span class="text-danger">*</span></label>
                        <select class="form-select container-select" name="containers[${containerIndex}][container_id]" required>
                            <option value="">Select Container</option>
                            @foreach($containers as $container)
                                <option value="{{ $container->id }}">
                                    {{ $container->code }} - {{ ucfirst(str_replace('_', ' ', $container->type)) }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Quantity <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="containers[${containerIndex}][no_of_containers]"
                               min="1" value="1" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Monthly Dumping <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="containers[${containerIndex}][monthly_dumping]"
                               min="0" value="0" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Price per Container <span class="text-danger">*</span></label>
                        <input type="number" class="form-control price-input" name="containers[${containerIndex}][price_per_container]"
                               step="0.01" min="0" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Additional Trip Price</label>
                        <input type="number" class="form-control" name="containers[${containerIndex}][additional_trip_price]"
                               step="0.01" min="0">
                    </div>
                    <div class="col-md-1 mb-3">
                        <label class="form-label">&nbsp;</label>
                        <button type="button" class="btn btn-danger btn-sm w-100 remove-container">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;

        containersContainer.insertAdjacentHTML('beforeend', containerHtml);
        containerIndex++;
        updateRemoveButtons();
        updateTotalValue();
    });

    // Remove container functionality
    containersContainer.addEventListener('click', function(e) {
        if (e.target.closest('.remove-container')) {
            e.target.closest('.container-item').remove();
            updateRemoveButtons();
            updateTotalValue();
        }
    });

    // Update total value when inputs change
    containersContainer.addEventListener('input', function(e) {
        if (e.target.matches('.price-input, input[name*="[no_of_containers]"], input[name*="[monthly_dumping]"], input[name*="[additional_trip_price]"]')) {
            updateTotalValue();
        }
    });

    function updateRemoveButtons() {
        const containerItems = containersContainer.querySelectorAll('.container-item');
        containerItems.forEach((item, index) => {
            const removeBtn = item.querySelector('.remove-container');
            removeBtn.style.display = containerItems.length > 1 ? 'block' : 'none';
        });
    }

    function updateTotalValue() {
        let total = 0;
        const containerItems = containersContainer.querySelectorAll('.container-item');

        containerItems.forEach(item => {
            const quantity = parseFloat(item.querySelector('input[name*="[no_of_containers]"]').value) || 0;
            const pricePerContainer = parseFloat(item.querySelector('input[name*="[price_per_container]"]').value) || 0;
            const monthlyDumping = parseFloat(item.querySelector('input[name*="[monthly_dumping]"]').value) || 0;
            const additionalTripPrice = parseFloat(item.querySelector('input[name*="[additional_trip_price]"]').value) || 0;

            const containerTotal = quantity * pricePerContainer;
            const dumpingTotal = monthlyDumping * additionalTripPrice;
            total += containerTotal + dumpingTotal;
        });

        totalValueSpan.textContent = total.toFixed(2);
    }

    // Initialize
    updateRemoveButtons();
    updateTotalValue();
});
</script>
@endsection
