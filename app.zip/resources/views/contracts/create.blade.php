@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Create New Contract</h4>
                    <a href="{{ route('contracts.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Contracts
                    </a>
                </div>

                <div class="card-body">
                    <form action="{{ route('contracts.store') }}" method="POST" id="contractForm">
                        @csrf

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="customer_id" class="form-label">Customer</label>
                                <select class="form-select @error('customer_id') is-invalid @enderror"
                                        id="customer_id" name="customer_id">
                                    <option value="">Select Customer</option>
                                    @foreach($customers as $customer)
                                        <option value="{{ $customer->id }}" {{ old('customer_id') == $customer->id ? 'selected' : '' }}>
                                            {{ $customer->name }} @if($customer->company_name) - {{ $customer->company_name }} @endif
                                        </option>
                                    @endforeach
                                </select>
                                @error('customer_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="type_id" class="form-label">Container Type</label>
                                <select class="form-select @error('type_id') is-invalid @enderror"
                                        id="type_id" name="type_id">
                                    <option value="">Select Container Type</option>
                                    @foreach($types as $type)
                                        <option value="{{ $type->id }}" {{ old('type_id') == $type->id ? 'selected' : '' }}>
                                            {{ $type->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('type_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                <select class="form-select @error('status') is-invalid @enderror"
                                        id="status" name="status" required>
                                    <option value="">Select Status</option>
                                    @foreach($statuses as $key => $label)
                                        <option value="{{ $key }}" {{ old('status') == $key ? 'selected' : '' }}>
                                            {{ $label }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('status')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="start_date" class="form-label">Start Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('start_date') is-invalid @enderror"
                                       id="start_date" name="start_date" value="{{ old('start_date') }}" required>
                                @error('start_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="end_date" class="form-label">End Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('end_date') is-invalid @enderror"
                                       id="end_date" name="end_date" value="{{ old('end_date') }}" required>
                                @error('end_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Quotation Information -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>{{ __('Quotation Information') }}</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="quotation_number" class="form-label">{{ __('Quotation Number') }}</label>
                                        <input type="text" class="form-control @error('quotation_number') is-invalid @enderror"
                                               id="quotation_number" name="quotation_number" value="{{ old('quotation_number') }}"
                                               placeholder="{{ __('Enter quotation number') }}">
                                        @error('quotation_number')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="quotation_date" class="form-label">{{ __('Quotation Date') }}</label>
                                        <input type="date" class="form-control @error('quotation_date') is-invalid @enderror"
                                               id="quotation_date" name="quotation_date" value="{{ old('quotation_date', now()->format('Y-m-d')) }}">
                                        @error('quotation_date')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="valid_until" class="form-label">{{ __('Valid Until') }}</label>
                                        <input type="date" class="form-control @error('valid_until') is-invalid @enderror"
                                               id="valid_until" name="valid_until" value="{{ old('valid_until', now()->addDays(30)->format('Y-m-d')) }}">
                                        @error('valid_until')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Customer Details -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>{{ __('Customer Details') }}</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="customer_name" class="form-label">{{ __('Customer Name') }}</label>
                                        <input type="text" class="form-control @error('customer_name') is-invalid @enderror"
                                               id="customer_name" name="customer_name" value="{{ old('customer_name') }}"
                                               placeholder="{{ __('Enter customer name') }}">
                                        @error('customer_name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="contact_person" class="form-label">{{ __('Contact Person') }}</label>
                                        <input type="text" class="form-control @error('contact_person') is-invalid @enderror"
                                               id="contact_person" name="contact_person" value="{{ old('contact_person') }}"
                                               placeholder="{{ __('Enter contact person name') }}">
                                        @error('contact_person')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label for="telephone" class="form-label">{{ __('Telephone') }}</label>
                                        <input type="text" class="form-control @error('telephone') is-invalid @enderror"
                                               id="telephone" name="telephone" value="{{ old('telephone') }}"
                                               placeholder="{{ __('Enter telephone') }}">
                                        @error('telephone')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="extension" class="form-label">{{ __('Extension') }}</label>
                                        <input type="text" class="form-control @error('extension') is-invalid @enderror"
                                               id="extension" name="extension" value="{{ old('extension') }}"
                                               placeholder="{{ __('Enter extension') }}">
                                        @error('extension')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="fax" class="form-label">{{ __('FAX') }}</label>
                                        <input type="text" class="form-control @error('fax') is-invalid @enderror"
                                               id="fax" name="fax" value="{{ old('fax') }}"
                                               placeholder="{{ __('Enter FAX') }}">
                                        @error('fax')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="mobile" class="form-label">{{ __('Mobile') }}</label>
                                        <input type="text" class="form-control @error('mobile') is-invalid @enderror"
                                               id="mobile" name="mobile" value="{{ old('mobile') }}"
                                               placeholder="{{ __('Enter mobile') }}">
                                        @error('mobile')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="city" class="form-label">{{ __('City') }}</label>
                                        <input type="text" class="form-control @error('city') is-invalid @enderror"
                                               id="city" name="city" value="{{ old('city') }}"
                                               placeholder="{{ __('Enter city') }}">
                                        @error('city')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="address" class="form-label">{{ __('Address') }}</label>
                                        <textarea class="form-control @error('address') is-invalid @enderror"
                                                  id="address" name="address" rows="2"
                                                  placeholder="{{ __('Enter address') }}">{{ old('address') }}</textarea>
                                        @error('address')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Company Information -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>{{ __('Company Information') }}</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="company_name" class="form-label">{{ __('Company Name') }}</label>
                                        <input type="text" class="form-control @error('company_name') is-invalid @enderror"
                                               id="company_name" name="company_name" value="{{ old('company_name', 'Support Lines Company') }}"
                                               placeholder="{{ __('Enter company name') }}">
                                        @error('company_name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="quotation_number" class="form-label">{{ __('Quotation Number') }}</label>
                                        <input type="text" class="form-control @error('quotation_number') is-invalid @enderror"
                                               id="quotation_number" name="quotation_number" value="{{ old('quotation_number', 'CR. ' . str_pad(rand(100000, 999999), 10, '0', STR_PAD_LEFT)) }}"
                                               placeholder="{{ __('Enter quotation number') }}">
                                        @error('quotation_number')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="company_phone" class="form-label">{{ __('Company Phone') }}</label>
                                        <input type="text" class="form-control @error('company_phone') is-invalid @enderror"
                                               id="company_phone" name="company_phone" value="{{ old('company_phone', '(966) 13 8060303') }}"
                                               placeholder="{{ __('Enter company phone') }}">
                                        @error('company_phone')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="company_email" class="form-label">{{ __('Company Email') }}</label>
                                        <input type="email" class="form-control @error('company_email') is-invalid @enderror"
                                               id="company_email" name="company_email" value="{{ old('company_email', 'info@support-lines.com') }}"
                                               placeholder="{{ __('Enter company email') }}">
                                        @error('company_email')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="company_website" class="form-label">{{ __('Company Website') }}</label>
                                        <input type="text" class="form-control @error('company_website') is-invalid @enderror"
                                               id="company_website" name="company_website" value="{{ old('company_website', 'support-lines.com') }}"
                                               placeholder="{{ __('Enter company website') }}">
                                        @error('company_website')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Service Details -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>{{ __('Service Details') }}</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label for="container_size" class="form-label">{{ __('Container Size') }}</label>
                                        <input type="text" class="form-control @error('container_size') is-invalid @enderror"
                                               id="container_size" name="container_size" value="{{ old('container_size', '12 Yards') }}"
                                               placeholder="{{ __('Enter container size') }}">
                                        @error('container_size')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="price_per_container" class="form-label">{{ __('Price per Container') }}</label>
                                        <input type="number" step="0.01" class="form-control @error('price_per_container') is-invalid @enderror"
                                               id="price_per_container" name="price_per_container" value="{{ old('price_per_container', 250) }}"
                                               placeholder="{{ __('Enter price per container') }}">
                                        @error('price_per_container')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="no_of_containers" class="form-label">{{ __('Number of Containers') }}</label>
                                        <input type="number" class="form-control @error('no_of_containers') is-invalid @enderror"
                                               id="no_of_containers" name="no_of_containers" value="{{ old('no_of_containers', 1) }}"
                                               placeholder="{{ __('Enter number of containers') }}">
                                        @error('no_of_containers')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="monthly_dumping_per_container" class="form-label">{{ __('Monthly Dumping per Container') }}</label>
                                        <input type="number" class="form-control @error('monthly_dumping_per_container') is-invalid @enderror"
                                               id="monthly_dumping_per_container" name="monthly_dumping_per_container" value="{{ old('monthly_dumping_per_container', 2) }}"
                                               placeholder="{{ __('Enter monthly dumping per container') }}">
                                        @error('monthly_dumping_per_container')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label for="total_dumping" class="form-label">{{ __('Total Dumping') }}</label>
                                        <input type="number" class="form-control @error('total_dumping') is-invalid @enderror"
                                               id="total_dumping" name="total_dumping" value="{{ old('total_dumping', 2) }}"
                                               placeholder="{{ __('Enter total dumping') }}">
                                        @error('total_dumping')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="additional_trips_price" class="form-label">{{ __('Additional Trips Price') }}</label>
                                        <input type="number" step="0.01" class="form-control @error('additional_trips_price') is-invalid @enderror"
                                               id="additional_trips_price" name="additional_trips_price" value="{{ old('additional_trips_price', 250) }}"
                                               placeholder="{{ __('Enter additional trips price') }}">
                                        @error('additional_trips_price')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="contract_period_months" class="form-label">{{ __('Contract Period (Months)') }}</label>
                                        <input type="number" class="form-control @error('contract_period_months') is-invalid @enderror"
                                               id="contract_period_months" name="contract_period_months" value="{{ old('contract_period_months', 12) }}"
                                               placeholder="{{ __('Enter contract period in months') }}">
                                        @error('contract_period_months')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="tax_value" class="form-label">{{ __('Tax Value (%)') }}</label>
                                        <input type="number" step="0.01" class="form-control @error('tax_value') is-invalid @enderror"
                                               id="tax_value" name="tax_value" value="{{ old('tax_value', 15) }}"
                                               placeholder="{{ __('Enter tax value') }}">
                                        @error('tax_value')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="total_monthly_price" class="form-label">{{ __('Total Monthly Price') }}</label>
                                        <input type="number" step="0.01" class="form-control @error('total_monthly_price') is-invalid @enderror"
                                               id="total_monthly_price" name="total_monthly_price" value="{{ old('total_monthly_price', 500) }}"
                                               placeholder="{{ __('Enter total monthly price') }}">
                                        @error('total_monthly_price')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="total_monthly_with_tax" class="form-label">{{ __('Total Monthly with Tax') }}</label>
                                        <input type="number" step="0.01" class="form-control @error('total_monthly_with_tax') is-invalid @enderror"
                                               id="total_monthly_with_tax" name="total_monthly_with_tax" value="{{ old('total_monthly_with_tax', 575) }}"
                                               placeholder="{{ __('Auto-calculated') }}" readonly>
                                        @error('total_monthly_with_tax')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="total_yearly_with_tax" class="form-label">{{ __('Total Yearly with Tax') }}</label>
                                        <input type="number" step="0.01" class="form-control @error('total_yearly_with_tax') is-invalid @enderror"
                                               id="total_yearly_with_tax" name="total_yearly_with_tax" value="{{ old('total_yearly_with_tax', 6900) }}"
                                               placeholder="{{ __('Auto-calculated') }}" readonly>
                                        @error('total_yearly_with_tax')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Terms and Conditions -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>{{ __('Terms and Conditions') }}</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="agreement_terms" class="form-label">{{ __('Agreement Terms') }}</label>
                                        <textarea class="form-control @error('agreement_terms') is-invalid @enderror"
                                                  id="agreement_terms" name="agreement_terms" rows="3"
                                                  placeholder="{{ __('Enter agreement terms') }}">{{ old('agreement_terms') }}</textarea>
                                        @error('agreement_terms')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="material_restrictions" class="form-label">{{ __('Material Restrictions') }}</label>
                                        <textarea class="form-control @error('material_restrictions') is-invalid @enderror"
                                                  id="material_restrictions" name="material_restrictions" rows="3"
                                                  placeholder="{{ __('Enter material restrictions') }}">{{ old('material_restrictions') }}</textarea>
                                        @error('material_restrictions')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="delivery_terms" class="form-label">{{ __('Delivery Terms') }}</label>
                                        <textarea class="form-control @error('delivery_terms') is-invalid @enderror"
                                                  id="delivery_terms" name="delivery_terms" rows="3"
                                                  placeholder="{{ __('Enter delivery terms') }}">{{ old('delivery_terms') }}</textarea>
                                        @error('delivery_terms')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="payment_policy" class="form-label">{{ __('Payment Policy') }}</label>
                                        <textarea class="form-control @error('payment_policy') is-invalid @enderror"
                                                  id="payment_policy" name="payment_policy" rows="3"
                                                  placeholder="{{ __('Enter payment policy') }}">{{ old('payment_policy') }}</textarea>
                                        @error('payment_policy')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="user_id" class="form-label">{{ __('User') }}</label>
                                <select class="form-select @error('user_id') is-invalid @enderror"
                                        id="user_id" name="user_id">
                                    <option value="">Select User</option>
                                    @foreach($users as $user)
                                        <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected' : '' }}>
                                            {{ $user->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('user_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="driver_id" class="form-label">{{ __('Driver ID') }}</label>
                                <input type="text" class="form-control @error('driver_id') is-invalid @enderror"
                                       id="driver_id" name="driver_id" value="{{ old('driver_id') }}"
                                       placeholder="Enter driver ID (optional)">
                                @error('driver_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="notes" class="form-label">{{ __('Notes') }}</label>
                                <textarea class="form-control @error('notes') is-invalid @enderror"
                                          id="notes" name="notes" rows="3"
                                          placeholder="{{ __('Enter contract notes (optional)') }}">{{ old('notes') }}</textarea>
                                @error('notes')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5>Container Details</h5>
                            <button type="button" class="btn btn-success btn-sm" id="addContainer">
                                <i class="fas fa-plus"></i> Add Container
                            </button>
                        </div>

                        <div id="containersContainer">
                            <div class="container-item border rounded p-3 mb-3">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label class="form-label">{{ __('Container Type') }} <span class="text-danger">*</span></label>
                                        <select class="form-select container-select" name="containers[0][type_id]" required>
                                            <option value="">{{ __('Select Container Type') }}</option>
                                            @foreach($types as $type)
                                                <option value="{{ $type->id }}">
                                                    {{ $type->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label class="form-label">Quantity <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control" name="containers[0][no_of_containers]"
                                               min="1" value="1" required>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label class="form-label">Monthly Dumping <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control" name="containers[0][monthly_dumping]"
                                               min="0" value="0" required>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label class="form-label">Price per Container <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control price-input" name="containers[0][price_per_container]"
                                               step="0.01" min="0" required>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label class="form-label">Additional Trip Price</label>
                                        <input type="number" class="form-control" name="containers[0][additional_trip_price]"
                                               step="0.01" min="0">
                                    </div>
                                    <div class="col-md-1 mb-3">
                                        <label class="form-label">&nbsp;</label>
                                        <button type="button" class="btn btn-danger btn-sm w-100 remove-container" style="display: none;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <strong>Total Contract Value: $<span id="totalValue">0.00</span></strong>
                        </div>

                        <div class="d-flex justify-content-end gap-2">
                            <a href="{{ route('contracts.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Create Contract
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<script>
document.addEventListener('DOMContentLoaded', function() {
    let containerIndex = 1;
    const containersContainer = document.getElementById('containersContainer');
    const addContainerBtn = document.getElementById('addContainer');
    const totalValueSpan = document.getElementById('totalValue');

    // Customer auto-fill functionality
    const customerSelect = document.getElementById('customer_id');
    customerSelect.addEventListener('change', function() {
        if (this.value) {
            fetch(`/contracts/customer/${this.value}/data`)
                .then(response => response.json())
                .then(data => {
                    // Auto-fill customer fields
                    document.getElementById('customer_name').value = data.name || '';
                    document.getElementById('contact_person').value = data.contact_person || '';
                    document.getElementById('telephone').value = data.telephone || '';
                    document.getElementById('extension').value = data.ext || '';
                    document.getElementById('fax').value = data.fax || '';
                    document.getElementById('mobile').value = data.mobile || '';
                    document.getElementById('city').value = data.city || '';
                    document.getElementById('address').value = data.address || '';
                })
                .catch(error => console.error('Error fetching customer data:', error));
        }
    });

    // Price calculation functionality
    const priceInputs = ['dumping_cost', 'no_containers', 'additional_trip_cost', 'tax_value'];
    priceInputs.forEach(inputId => {
        const input = document.getElementById(inputId);
        if (input) {
            input.addEventListener('input', calculatePrice);
        }
    });

    function calculatePrice() {
        const dumpingCost = parseFloat(document.getElementById('dumping_cost').value) || 0;
        const noContainers = parseFloat(document.getElementById('no_containers').value) || 0;
        const additionalTripCost = parseFloat(document.getElementById('additional_trip_cost').value) || 0;
        const taxValue = parseFloat(document.getElementById('tax_value').value) || 14;

        const monthlyTotalDumpingCost = dumpingCost * noContainers;
        const subtotal = monthlyTotalDumpingCost + additionalTripCost;
        const taxAmount = subtotal * (taxValue / 100);
        const totalPrice = subtotal + taxAmount;

        // Update the calculated fields
        document.getElementById('monthly_total_dumping_cost').value = monthlyTotalDumpingCost.toFixed(2);
        document.getElementById('total_price').value = totalPrice.toFixed(2);
    }

    // Add container functionality
    addContainerBtn.addEventListener('click', function() {
        const containerHtml = `
            <div class="container-item border rounded p-3 mb-3">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Container <span class="text-danger">*</span></label>
                        <select class="form-select container-select" name="containers[${containerIndex}][type_id]" required>
                            <option value="">{{ __('Select Container Type') }}</option>
                            @foreach($types as $type)
                                <option value="{{ $type->id }}">
                                    {{ $type->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Quantity <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="containers[${containerIndex}][no_of_containers]"
                               min="1" value="1" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Monthly Dumping <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="containers[${containerIndex}][monthly_dumping]"
                               min="0" value="0" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Price per Container <span class="text-danger">*</span></label>
                        <input type="number" class="form-control price-input" name="containers[${containerIndex}][price_per_container]"
                               step="0.01" min="0" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">Additional Trip Price</label>
                        <input type="number" class="form-control" name="containers[${containerIndex}][additional_trip_price]"
                               step="0.01" min="0">
                    </div>
                    <div class="col-md-1 mb-3">
                        <label class="form-label">&nbsp;</label>
                        <button type="button" class="btn btn-danger btn-sm w-100 remove-container">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;

        containersContainer.insertAdjacentHTML('beforeend', containerHtml);
        containerIndex++;
        updateRemoveButtons();
        updateTotalValue();
    });

    // Remove container functionality
    containersContainer.addEventListener('click', function(e) {
        if (e.target.closest('.remove-container')) {
            e.target.closest('.container-item').remove();
            updateRemoveButtons();
            updateTotalValue();
        }
    });

    // Update total value when inputs change
    containersContainer.addEventListener('input', function(e) {
        if (e.target.matches('.price-input, input[name*="[no_of_containers]"], input[name*="[monthly_dumping]"], input[name*="[additional_trip_price]"]')) {
            updateTotalValue();
        }
    });

    function updateRemoveButtons() {
        const containerItems = containersContainer.querySelectorAll('.container-item');
        containerItems.forEach((item, index) => {
            const removeBtn = item.querySelector('.remove-container');
            removeBtn.style.display = containerItems.length > 1 ? 'block' : 'none';
        });
    }

    function updateTotalValue() {
        let total = 0;
        const containerItems = containersContainer.querySelectorAll('.container-item');

        containerItems.forEach(item => {
            const quantity = parseFloat(item.querySelector('input[name*="[no_of_containers]"]').value) || 0;
            const pricePerContainer = parseFloat(item.querySelector('input[name*="[price_per_container]"]').value) || 0;
            const monthlyDumping = parseFloat(item.querySelector('input[name*="[monthly_dumping]"]').value) || 0;
            const additionalTripPrice = parseFloat(item.querySelector('input[name*="[additional_trip_price]"]').value) || 0;

            const containerTotal = quantity * pricePerContainer;
            const dumpingTotal = monthlyDumping * additionalTripPrice;
            total += containerTotal + dumpingTotal;
        });

        totalValueSpan.textContent = total.toFixed(2);
    }

    // Initialize
    updateRemoveButtons();
    updateTotalValue();
});
</script>
@endsection
