<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation - {{ $quotation_number }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .header {
            border-bottom: 2px solid #007bff;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .company-info {
            float: left;
            width: 50%;
        }
        .quotation-info {
            float: right;
            width: 45%;
            text-align: right;
        }
        .clearfix::after {
            content: "";
            display: table;
            clear: both;
        }
        .customer-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 30px;
        }
        .quotation-details {
            margin-bottom: 30px;
        }
        .container-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .container-table th,
        .container-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .container-table th {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }
        .container-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .total-section {
            text-align: right;
            margin-top: 20px;
        }
        .total-amount {
            font-size: 18px;
            font-weight: bold;
            color: #007bff;
        }
        .terms-section {
            margin-top: 40px;
            page-break-inside: avoid;
        }
        .signature-section {
            margin-top: 60px;
            page-break-inside: avoid;
        }
        .signature-box {
            border: 1px solid #ddd;
            height: 80px;
            margin-top: 10px;
        }
        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 20px;
        }
        h1 {
            color: #007bff;
            margin: 0;
            font-size: 24px;
        }
        h2 {
            color: #333;
            margin: 20px 0 10px 0;
            font-size: 16px;
        }
        .label {
            font-weight: bold;
            display: inline-block;
            width: 120px;
        }
        .value {
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="header clearfix">
        <div class="company-info">
            <h1>{{ $company['name'] }}</h1>
            <p>{{ $company['address'] }}<br>
            Phone: {{ $company['phone'] }}<br>
            Email: {{ $company['email'] }}</p>
        </div>
        <div class="quotation-info">
            <h2>QUOTATION</h2>
            <p><strong>Quotation #:</strong> {{ $quotation_number }}<br>
            <strong>Date:</strong> {{ $generated_date }}<br>
            <strong>Contract #:</strong> {{ $contract->id }}</p>
        </div>
    </div>

    <div class="customer-info">
        <h2>Customer Information</h2>
        <p><span class="label">Name:</span> <span class="value">{{ $contract->customer->name }}</span><br>
        @if($contract->customer->company_name)
        <span class="label">Company:</span> <span class="value">{{ $contract->customer->company_name }}</span><br>
        @endif
        @if($contract->customer->phone)
        <span class="label">Phone:</span> <span class="value">{{ $contract->customer->phone }}</span><br>
        @endif
        @if($contract->customer->email)
        <span class="label">Email:</span> <span class="value">{{ $contract->customer->email }}</span><br>
        @endif
        @if($contract->customer->address)
        <span class="label">Address:</span> <span class="value">{{ $contract->customer->address }}</span>
        @endif</p>
    </div>

    <div class="quotation-details">
        <h2>Contract Details</h2>
        <p><span class="label">Start Date:</span> <span class="value">{{ $contract->start_date->format('M d, Y') }}</span><br>
        <span class="label">End Date:</span> <span class="value">{{ $contract->end_date->format('M d, Y') }}</span><br>
        <span class="label">Contract Period:</span> <span class="value">{{ $contract->contract_period_days }} days</span><br>
        <span class="label">Status:</span> <span class="value">{{ $contract->status->label() }}</span></p>
    </div>

    <h2>Container Services</h2>
    <table class="container-table">
        <thead>
            <tr>
                <th>Container Code</th>
                <th>Type</th>
                <th>Quantity</th>
                <th>Monthly Dumping</th>
                <th>Price per Container</th>
                <th>Additional Trip Price</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($contract->contractContainers as $contractContainer)
            <tr>
                <td>{{ $contractContainer->container->code }}</td>
                <td>{{ ucfirst(str_replace('_', ' ', $contractContainer->container->type)) }}</td>
                <td>{{ $contractContainer->no_of_containers }}</td>
                <td>{{ $contractContainer->monthly_dumping }}</td>
                <td>${{ number_format($contractContainer->price_per_container, 2) }}</td>
                <td>
                    @if($contractContainer->additional_trip_price)
                        ${{ number_format($contractContainer->additional_trip_price, 2) }}
                    @else
                        N/A
                    @endif
                </td>
                <td>${{ number_format($contractContainer->total_price, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="total-section">
        <p><strong>Total Contract Value: <span class="total-amount">${{ number_format($contract->total_price, 2) }}</span></strong></p>
    </div>

    @if($contract->notes)
    <div class="terms-section">
        <h2>Additional Notes</h2>
        <p>{{ $contract->notes }}</p>
    </div>
    @endif

    <div class="terms-section">
        <h2>Terms & Conditions</h2>
        <ul>
            <li>Payment terms: Net 30 days from invoice date</li>
            <li>Late payment charges: 1.5% per month on outstanding amounts</li>
            <li>Container delivery and pickup included in monthly service</li>
            <li>Additional dumping trips will be charged as per the quoted rate</li>
            <li>Contract can be terminated with 30 days written notice</li>
            <li>All prices are subject to applicable taxes</li>
            <li>Container maintenance and repairs are included in the service</li>
        </ul>
    </div>

    <div class="signature-section">
        <div style="width: 48%; float: left;">
            <h3>Customer Signature</h3>
            <div class="signature-box"></div>
            <p>Date: _______________</p>
        </div>
        <div style="width: 48%; float: right;">
            <h3>Company Representative</h3>
            <div class="signature-box"></div>
            <p>Date: _______________</p>
        </div>
        <div class="clearfix"></div>
    </div>

    <div class="footer">
        <p>This quotation is valid for 30 days from the date of issue.<br>
        For any questions regarding this quotation, please contact us at {{ $company['phone'] }} or {{ $company['email'] }}</p>
    </div>
</body>
</html>
