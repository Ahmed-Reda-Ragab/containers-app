@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Payment Details</h4>
                    <div class="btn-group" role="group">
                        <a href="{{ route('payments.edit', $payment) }}" class="btn btn-outline-secondary">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="{{ route('payments.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Payments
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Payment Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>ID:</strong></td>
                                    <td>{{ $payment->id }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Amount:</strong></td>
                                    <td>${{ number_format($payment->payed, 2) }}</td>
                                </tr>
                                <tr>
                                    <td><strong>User:</strong></td>
                                    <td>{{ $payment->user->name ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Created At:</strong></td>
                                    <td>{{ $payment->created_at->format('Y-m-d H:i:s') }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Updated At:</strong></td>
                                    <td>{{ $payment->updated_at->format('Y-m-d H:i:s') }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6>Contract Information</h6>
                            @if($payment->contract)
                                <table class="table table-borderless">
                                    <tr>
                                        <td><strong>Contract ID:</strong></td>
                                        <td>
                                            <a href="{{ route('contracts.show', $payment->contract) }}">
                                                #{{ $payment->contract->id }}
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Customer:</strong></td>
                                        <td>{{ $payment->contract->customer->name ?? 'N/A' }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status:</strong></td>
                                        <td>
                                            <span class="badge bg-{{ $payment->contract->status == 'active' ? 'success' : ($payment->contract->status == 'pending' ? 'warning' : 'secondary') }}">
                                                {{ ucfirst($payment->contract->status) }}
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Total Price:</strong></td>
                                        <td>${{ number_format($payment->contract->total_price, 2) }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Total Payed:</strong></td>
                                        <td>${{ number_format($payment->contract->total_payed, 2) }}</td>
                                    </tr>
                                </table>
                            @else
                                <p class="text-muted">No contract associated with this payment.</p>
                            @endif
                        </div>
                    </div>

                    @if($payment->notes)
                        <div class="mt-4">
                            <h6>Notes</h6>
                            <div class="card">
                                <div class="card-body">
                                    <p class="mb-0">{{ $payment->notes }}</p>
                                </div>
                            </div>
                        </div>
                    @endif

                    <div class="mt-4">
                        <form action="{{ route('payments.destroy', $payment) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this payment?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash"></i> Delete Payment
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
@endsection
