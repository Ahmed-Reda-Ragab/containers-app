@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">{{ __('Offers Management') }}</h4>
                    <a href="{{ route('offers.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i> {{ __('Create New Offer') }}
                    </a>
                </div>

                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @if($offers->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>{{ __('Offer #') }}</th>
                                        <th>{{ __('Customer') }}</th>
                                        <th>{{ __('Offer Date') }}</th>
                                        <th>{{ __('Valid Until') }}</th>
                                        <th>{{ __('Total Price') }}</th>
                                        <th>{{ __('Status') }}</th>
                                        <th>{{ __('Actions') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($offers as $offer)
                                        <tr>
                                            <td>
                                                <strong>{{ $offer->offer_number }}</strong>
                                            </td>
                                            <td>
                                                <strong>{{ $offer->customer_name }}</strong>
                                                @if($offer->customer && $offer->customer->company_name)
                                                    <br><small class="text-muted">{{ $offer->customer->company_name }}</small>
                                                @endif
                                            </td>
                                            <td>{{ $offer->offer_date->format('M d, Y') }}</td>
                                            <td>
                                                @if($offer->valid_until < now())
                                                    <span class="text-danger">{{ $offer->valid_until->format('M d, Y') }}</span>
                                                @else
                                                    {{ $offer->valid_until->format('M d, Y') }}
                                                @endif
                                            </td>
                                            <td>
                                                <strong class="text-success">${{ number_format($offer->total_price, 2) }}</strong>
                                            </td>
                                            <td>
                                                @php
                                                    $statusClass = match($offer->status->value) {
                                                        'draft' => 'secondary',
                                                        'sent' => 'primary',
                                                        'accepted' => 'success',
                                                        'rejected' => 'danger',
                                                        'expired' => 'warning',
                                                        default => 'secondary'
                                                    };
                                                @endphp
                                                <span class="badge bg-{{ $statusClass }}">{{ $offer->status->label() }}</span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="{{ route('offers.show', $offer) }}" class="btn btn-sm btn-outline-info" title="{{ __('View') }}">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="{{ route('offers.edit', $offer) }}" class="btn btn-sm btn-outline-warning" title="{{ __('Edit') }}">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="{{ route('offers.download', $offer) }}" class="btn btn-sm btn-outline-primary" title="{{ __('Download PDF') }}">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <form action="{{ route('offers.destroy', $offer) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Are you sure you want to delete this offer?') }}')">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="{{ __('Delete') }}">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-center">
                            {{ $offers->links() }}
                        </div>
                    @else
                        <div class="text-center py-5">
                            <i class="fas fa-file-invoice fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">{{ __('No offers found') }}</h5>
                            <p class="text-muted">{{ __('Get started by creating your first offer.') }}</p>
                            <a href="{{ route('offers.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> {{ __('Create New Offer') }}
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
@endsection
