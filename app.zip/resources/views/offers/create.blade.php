@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Create New Offer</h4>
                    <a href="{{ route('offers.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Offers
                    </a>
                </div>

                <div class="card-body">
                    <form action="{{ route('offers.store') }}" method="POST" id="offerForm">
                        @csrf

                        <!-- Header Section -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5 class="text-primary">عرض تأجير حاويات / Dumpster Rental Quotation</h5>
                            </div>
                            <div class="col-md-3">
                                <label for="offer_date" class="form-label">التاريخ / Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('offer_date') is-invalid @enderror"
                                       id="offer_date" name="offer_date" value="{{ old('offer_date', now()->format('Y-m-d')) }}" required>
                                @error('offer_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-3">
                                <label for="offer_number" class="form-label">رقم العرض / Quotation No. <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('offer_number') is-invalid @enderror"
                                       id="offer_number" name="offer_number" value="{{ old('offer_number', $offerNumber) }}" required>
                                @error('offer_number')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Customer Information Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">معلومات العميل / Customer Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="customer_id" class="form-label">Customer <span class="text-danger">*</span></label>
                                        <select class="form-select @error('customer_id') is-invalid @enderror"
                                                id="customer_id" name="customer_id" required onchange="loadCustomerData()">
                                            <option value="">Select Customer</option>
                                            @foreach($customers as $customer)
                                                <option value="{{ $customer->id }}" data-name="{{ $customer->name }}"
                                                        data-phone="{{ $customer->phone }}" data-email="{{ $customer->email }}"
                                                        data-address="{{ $customer->address }}" data-company="{{ $customer->company_name }}"
                                                        {{ old('customer_id') == $customer->id ? 'selected' : '' }}>
                                                    {{ $customer->name }} @if($customer->company_name) - {{ $customer->company_name }} @endif
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('customer_id')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="customer_name" class="form-label">اسم العميل / Customer Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control @error('customer_name') is-invalid @enderror"
                                               id="customer_name" name="customer_name" value="{{ old('customer_name') }}" required>
                                        @error('customer_name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="contact_person" class="form-label">المسئول / Contact Person</label>
                                        <input type="text" class="form-control @error('contact_person') is-invalid @enderror"
                                               id="contact_person" name="contact_person" value="{{ old('contact_person') }}">
                                        @error('contact_person')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="telephone" class="form-label">الهاتف / Telephone</label>
                                        <input type="text" class="form-control @error('telephone') is-invalid @enderror"
                                               id="telephone" name="telephone" value="{{ old('telephone') }}">
                                        @error('telephone')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label for="extension" class="form-label">تحویله / Ext.</label>
                                        <input type="text" class="form-control @error('extension') is-invalid @enderror"
                                               id="extension" name="extension" value="{{ old('extension') }}">
                                        @error('extension')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="fax" class="form-label">الفاكس / FAX</label>
                                        <input type="text" class="form-control @error('fax') is-invalid @enderror"
                                               id="fax" name="fax" value="{{ old('fax') }}">
                                        @error('fax')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="mobile" class="form-label">الجوال / Mobile</label>
                                        <input type="text" class="form-control @error('mobile') is-invalid @enderror"
                                               id="mobile" name="mobile" value="{{ old('mobile') }}">
                                        @error('mobile')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="city" class="form-label">المدينة / City</label>
                                        <input type="text" class="form-control @error('city') is-invalid @enderror"
                                               id="city" name="city" value="{{ old('city') }}">
                                        @error('city')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <label for="address" class="form-label">العنوان / Address</label>
                                        <textarea class="form-control @error('address') is-invalid @enderror"
                                                  id="address" name="address" rows="2">{{ old('address') }}</textarea>
                                        @error('address')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Service Details Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">تفاصيل الخدمة / Service Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6>Container Details</h6>
                                    <button type="button" class="btn btn-success btn-sm" id="addContainer">
                                        <i class="fas fa-plus"></i> Add Container
                                    </button>
                                </div>

                                <div id="containersContainer">
                                    <div class="container-item border rounded p-3 mb-3">
                                        <div class="row">
                                            <div class="col-md-3 mb-3">
                                                <label class="form-label">حجم الحاوية / Container Size <span class="text-danger">*</span></label>
                                                <select class="form-select container-select" name="containers[0][container_id]" required>
                                                    <option value="">Select Container</option>
                                                    @foreach($containers as $container)
                                                        <option value="{{ $container->id }}" data-size="{{ $container->size }}">
                                                            {{ $container->code }} - {{ ucfirst(str_replace('_', ' ', $container->type)) }} @if($container->size) ({{ $container->size }}) @endif
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-2 mb-3">
                                                <label class="form-label">السعر / حاوية / Price/Container <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control price-input" name="containers[0][price_per_container]"
                                                       step="0.01" min="0" required>
                                            </div>
                                            <div class="col-md-2 mb-3">
                                                <label class="form-label">عدد الحاويات / No. of Containers <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control quantity-input" name="containers[0][no_of_containers]"
                                                       min="1" value="1" required>
                                            </div>
                                            <div class="col-md-2 mb-3">
                                                <label class="form-label">عدد التفريغ الشهري / حاوية / Monthly Dumping/Cont. <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control dumping-input" name="containers[0][monthly_dumping_per_container]"
                                                       min="0" value="0" required>
                                            </div>
                                            <div class="col-md-2 mb-3">
                                                <label class="form-label">إجمالي عدد التفريغ الشهري / Total Dumping</label>
                                                <input type="number" class="form-control total-dumping" readonly>
                                            </div>
                                            <div class="col-md-1 mb-3">
                                                <label class="form-label">&nbsp;</label>
                                                <button type="button" class="btn btn-danger btn-sm w-100 remove-container" style="display: none;">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label for="additional_trip_price" class="form-label">الرفع الإضافي / Additional Trips <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control @error('additional_trip_price') is-invalid @enderror"
                                               id="additional_trip_price" name="additional_trip_price"
                                               step="0.01" min="0" value="{{ old('additional_trip_price', 250) }}" required>
                                        @error('additional_trip_price')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="contract_period_days" class="form-label">مدة ايجار الحاوية الواحدة / Contract Period <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control @error('contract_period_days') is-invalid @enderror"
                                               id="contract_period_days" name="contract_period_days"
                                               min="1" value="{{ old('contract_period_days', 10) }}" required>
                                        @error('contract_period_days')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="valid_until" class="form-label">Valid Until <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control @error('valid_until') is-invalid @enderror"
                                               id="valid_until" name="valid_until" value="{{ old('valid_until', now()->addDays(30)->format('Y-m-d')) }}" required>
                                        @error('valid_until')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                        <select class="form-select @error('status') is-invalid @enderror"
                                                id="status" name="status" required>
                                            <option value="">Select Status</option>
                                            @foreach($statuses as $key => $label)
                                                <option value="{{ $key }}" {{ old('status') == $key ? 'selected' : '' }}>
                                                    {{ $label }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('status')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="alert alert-info">
                                    <strong>إجمالي الاتفاقية الشهرية / Total Monthly Price: $<span id="totalMonthlyPrice">0.00</span></strong><br>
                                    <strong>إجمالي الاتفاقية الشهرية / Total Price: $<span id="totalPrice">0.00</span></strong>
                                </div>
                            </div>
                        </div>

                        <!-- Terms and Conditions -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Terms & Conditions</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="agreement_terms" class="form-label">Agreement Terms</label>
                                        <textarea class="form-control @error('agreement_terms') is-invalid @enderror"
                                                  id="agreement_terms" name="agreement_terms" rows="3">{{ old('agreement_terms', 'Rtm Arabia EST. agree to provide the disposal services and/or equipments specified herein and customer agrees to make the payment as provided for herein and abide by the terms and conditions of this agreement.') }}</textarea>
                                        @error('agreement_terms')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="material_restrictions" class="form-label">Material Restrictions</label>
                                        <textarea class="form-control @error('material_restrictions') is-invalid @enderror"
                                                  id="material_restrictions" name="material_restrictions" rows="3">{{ old('material_restrictions', 'Material that will be collected and disposed by Rtm Arabia EST. is solid material generated by customer excluding radioactive, volatile, highly flammable, explosive, toxic or hazardous material.') }}</textarea>
                                        @error('material_restrictions')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="delivery_terms" class="form-label">Delivery Terms</label>
                                        <textarea class="form-control @error('delivery_terms') is-invalid @enderror"
                                                  id="delivery_terms" name="delivery_terms" rows="3">{{ old('delivery_terms', 'Any delivered container shall come with service delivery note/receipt even additional trips. Container will be delivered when requested by customer. Customer is entitled to request the container within six months from the date of the contract.') }}</textarea>
                                        @error('delivery_terms')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="payment_policy" class="form-label">Payment Policy</label>
                                        <textarea class="form-control @error('payment_policy') is-invalid @enderror"
                                                  id="payment_policy" name="payment_policy" rows="3">{{ old('payment_policy', 'The amount due will be paid immediately from the date of issue of the invoice according to the agreement between the customer and RTM.') }}</textarea>
                                        @error('payment_policy')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="notes" class="form-label">Additional Notes</label>
                                    <textarea class="form-control @error('notes') is-invalid @enderror"
                                              id="notes" name="notes" rows="2" placeholder="Enter any additional notes">{{ old('notes') }}</textarea>
                                    @error('notes')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2">
                            <a href="{{ route('offers.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Create Offer
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<script>
document.addEventListener('DOMContentLoaded', function() {
    let containerIndex = 1;
    const containersContainer = document.getElementById('containersContainer');
    const addContainerBtn = document.getElementById('addContainer');
    const totalMonthlyPriceSpan = document.getElementById('totalMonthlyPrice');
    const totalPriceSpan = document.getElementById('totalPrice');

    // Load customer data when customer is selected
    function loadCustomerData() {
        const customerSelect = document.getElementById('customer_id');
        const selectedOption = customerSelect.options[customerSelect.selectedIndex];

        if (selectedOption.value) {
            document.getElementById('customer_name').value = selectedOption.dataset.name || '';
            document.getElementById('telephone').value = selectedOption.dataset.phone || '';
            document.getElementById('address').value = selectedOption.dataset.address || '';
        }
    }

    // Add container functionality
    addContainerBtn.addEventListener('click', function() {
        const containerHtml = `
            <div class="container-item border rounded p-3 mb-3">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">حجم الحاوية / Container Size <span class="text-danger">*</span></label>
                        <select class="form-select container-select" name="containers[${containerIndex}][container_id]" required>
                            <option value="">Select Container</option>
                            @foreach($containers as $container)
                                <option value="{{ $container->id }}" data-size="{{ $container->size }}">
                                    {{ $container->code }} - {{ ucfirst(str_replace('_', ' ', $container->type)) }} @if($container->size) ({{ $container->size }}) @endif
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">السعر / حاوية / Price/Container <span class="text-danger">*</span></label>
                        <input type="number" class="form-control price-input" name="containers[${containerIndex}][price_per_container]"
                               step="0.01" min="0" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">عدد الحاويات / No. of Containers <span class="text-danger">*</span></label>
                        <input type="number" class="form-control quantity-input" name="containers[${containerIndex}][no_of_containers]"
                               min="1" value="1" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">عدد التفريغ الشهري / حاوية / Monthly Dumping/Cont. <span class="text-danger">*</span></label>
                        <input type="number" class="form-control dumping-input" name="containers[${containerIndex}][monthly_dumping_per_container]"
                               min="0" value="0" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label class="form-label">إجمالي عدد التفريغ الشهري / Total Dumping</label>
                        <input type="number" class="form-control total-dumping" readonly>
                    </div>
                    <div class="col-md-1 mb-3">
                        <label class="form-label">&nbsp;</label>
                        <button type="button" class="btn btn-danger btn-sm w-100 remove-container">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;

        containersContainer.insertAdjacentHTML('beforeend', containerHtml);
        containerIndex++;
        updateRemoveButtons();
        updateTotals();
    });

    // Remove container functionality
    containersContainer.addEventListener('click', function(e) {
        if (e.target.closest('.remove-container')) {
            e.target.closest('.container-item').remove();
            updateRemoveButtons();
            updateTotals();
        }
    });

    // Update totals when inputs change
    containersContainer.addEventListener('input', function(e) {
        if (e.target.matches('.price-input, .quantity-input, .dumping-input')) {
            updateContainerTotals(e.target.closest('.container-item'));
            updateTotals();
        }
    });

    function updateContainerTotals(containerItem) {
        const quantity = parseFloat(containerItem.querySelector('.quantity-input').value) || 0;
        const dumping = parseFloat(containerItem.querySelector('.dumping-input').value) || 0;
        const totalDumping = quantity * dumping;

        containerItem.querySelector('.total-dumping').value = totalDumping;
    }

    function updateRemoveButtons() {
        const containerItems = containersContainer.querySelectorAll('.container-item');
        containerItems.forEach((item, index) => {
            const removeBtn = item.querySelector('.remove-container');
            removeBtn.style.display = containerItems.length > 1 ? 'block' : 'none';
        });
    }

    function updateTotals() {
        let totalMonthlyPrice = 0;
        const containerItems = containersContainer.querySelectorAll('.container-item');

        containerItems.forEach(item => {
            const quantity = parseFloat(item.querySelector('.quantity-input').value) || 0;
            const pricePerContainer = parseFloat(item.querySelector('.price-input').value) || 0;
            const monthlyPrice = quantity * pricePerContainer;
            totalMonthlyPrice += monthlyPrice;
        });

        totalMonthlyPriceSpan.textContent = totalMonthlyPrice.toFixed(2);
        totalPriceSpan.textContent = totalMonthlyPrice.toFixed(2);
    }

    // Initialize
    updateRemoveButtons();
    updateTotals();

    // Update totals for existing containers
    containersContainer.querySelectorAll('.container-item').forEach(updateContainerTotals);
});
</script>
@endsection
