<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            // Company information
            $table->string('company_name')->nullable()->after('user_id');
            $table->string('company_logo')->nullable()->after('company_name');
            $table->string('company_address')->nullable()->after('company_logo');
            $table->string('company_phone')->nullable()->after('company_address');
            $table->string('company_email')->nullable()->after('company_phone');
            $table->string('company_website')->nullable()->after('company_email');
            $table->string('company_pobox')->nullable()->after('company_website');
            
            // Quotation specific fields
            $table->string('quotation_number')->nullable()->after('company_pobox');
            $table->string('quotation_serial')->nullable()->after('quotation_number');
            $table->date('quotation_date')->nullable()->after('quotation_serial');
            $table->integer('validity_days')->default(30)->after('quotation_date');
            
            // Customer specific fields (JSON structure)
            $table->json('customer_details')->nullable()->after('validity_days');
            
            // Service details
            $table->string('container_size')->nullable()->after('customer_details');
            $table->decimal('price_per_container', 10, 2)->nullable()->after('container_size');
            $table->integer('no_of_containers')->nullable()->after('price_per_container');
            $table->integer('monthly_dumping_per_container')->nullable()->after('no_of_containers');
            $table->integer('total_dumping')->nullable()->after('monthly_dumping_per_container');
            $table->decimal('additional_trips_price', 10, 2)->nullable()->after('total_dumping');
            $table->integer('contract_period_months')->nullable()->after('additional_trips_price');
            $table->decimal('total_monthly_price', 10, 2)->nullable()->after('contract_period_months');
            $table->decimal('total_monthly_with_tax', 10, 2)->nullable()->after('total_monthly_price');
            $table->decimal('total_yearly_with_tax', 10, 2)->nullable()->after('total_monthly_with_tax');
            
            // Terms and conditions
            $table->text('agreement_terms_ar')->nullable()->after('total_yearly_with_tax');
            $table->text('material_restrictions_ar')->nullable()->after('agreement_terms_ar');
            $table->text('receiving_terms_ar')->nullable()->after('material_restrictions_ar');
            $table->text('notes_ar')->nullable()->after('receiving_terms_ar');
            $table->text('payment_policy_ar')->nullable()->after('notes_ar');
            
            // Discounts
            $table->decimal('advance_payment_one_year_discount', 5, 2)->default(10)->after('payment_policy_ar');
            $table->decimal('advance_payment_six_months_discount', 5, 2)->default(5)->after('advance_payment_one_year_discount');
            
            // Signatures
            $table->string('manager_name')->nullable()->after('advance_payment_six_months_discount');
            $table->string('manager_signature')->nullable()->after('manager_name');
            $table->string('supervisor_name')->nullable()->after('manager_signature');
            $table->string('supervisor_signature')->nullable()->after('supervisor_name');
            $table->string('supervisor_mobile')->nullable()->after('supervisor_signature');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn([
                'company_name', 'company_logo', 'company_address', 'company_phone', 
                'company_email', 'company_website', 'company_pobox',
                'quotation_number', 'quotation_serial', 'quotation_date', 'validity_days',
                'customer_details', 'container_size', 'price_per_container', 'no_of_containers',
                'monthly_dumping_per_container', 'total_dumping', 'additional_trips_price',
                'contract_period_months', 'total_monthly_price', 'total_monthly_with_tax',
                'total_yearly_with_tax', 'agreement_terms_ar', 'material_restrictions_ar',
                'receiving_terms_ar', 'notes_ar', 'payment_policy_ar',
                'advance_payment_one_year_discount', 'advance_payment_six_months_discount',
                'manager_name', 'manager_signature', 'supervisor_name', 'supervisor_signature', 'supervisor_mobile'
            ]);
        });
    }
};
