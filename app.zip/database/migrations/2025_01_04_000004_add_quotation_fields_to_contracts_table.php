<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->string('quotation_number')->nullable()->after('customer_id');
            $table->date('quotation_date')->nullable()->after('quotation_number');
            $table->string('customer_name')->nullable()->after('quotation_date');
            $table->string('contact_person')->nullable()->after('customer_name');
            $table->string('telephone')->nullable()->after('contact_person');
            $table->string('extension')->nullable()->after('telephone');
            $table->string('fax')->nullable()->after('extension');
            $table->string('mobile')->nullable()->after('fax');
            $table->string('city')->nullable()->after('mobile');
            $table->text('address')->nullable()->after('city');
            $table->decimal('total_monthly_price', 10, 2)->nullable()->after('total_price');
            $table->decimal('additional_trip_price', 10, 2)->nullable()->after('total_monthly_price');
            $table->text('agreement_terms')->nullable()->after('notes');
            $table->text('material_restrictions')->nullable()->after('agreement_terms');
            $table->text('delivery_terms')->nullable()->after('material_restrictions');
            $table->text('payment_policy')->nullable()->after('delivery_terms');
            $table->date('valid_until')->nullable()->after('payment_policy');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn([
                'quotation_number',
                'quotation_date',
                'customer_name',
                'contact_person',
                'telephone',
                'extension',
                'fax',
                'mobile',
                'city',
                'address',
                'total_monthly_price',
                'additional_trip_price',
                'agreement_terms',
                'material_restrictions',
                'delivery_terms',
                'payment_policy',
                'valid_until'
            ]);
        });
    }
};
