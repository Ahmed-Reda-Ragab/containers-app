<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('offers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained()->onDelete('cascade');
            $table->string('offer_number')->unique();
            $table->date('offer_date');
            $table->date('valid_until');

            // Customer Information
            $table->string('customer_name');
            $table->string('contact_person')->nullable();
            $table->string('telephone')->nullable();
            $table->string('extension')->nullable();
            $table->string('fax')->nullable();
            $table->string('mobile')->nullable();
            $table->string('city')->nullable();
            $table->text('address')->nullable();

            // Service Details
            $table->integer('contract_period_days')->default(10);
            $table->decimal('additional_trip_price', 10, 2)->default(250.00);
            $table->decimal('total_monthly_price', 10, 2)->default(0.00);
            $table->decimal('total_price', 10, 2)->default(0.00);

            // Status and Notes
            $table->string('status')->default('draft'); // draft, sent, accepted, rejected, expired
            $table->text('notes')->nullable();
            $table->text('agreement_terms')->nullable();
            $table->text('material_restrictions')->nullable();
            $table->text('delivery_terms')->nullable();
            $table->text('payment_policy')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('offers');
    }
};
