<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->string('contact_person')->nullable()->after('company_name');
            $table->string('telephone')->nullable()->after('contact_person');
            $table->string('ext')->nullable()->after('telephone');
            $table->string('fax')->nullable()->after('ext');
            $table->string('mobile')->nullable()->after('fax');
            $table->string('city')->nullable()->after('mobile');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->dropColumn(['contact_person', 'telephone', 'ext', 'fax', 'mobile', 'city']);
        });
    }
};