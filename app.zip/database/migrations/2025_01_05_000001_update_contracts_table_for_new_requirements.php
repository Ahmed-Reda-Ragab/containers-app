<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            // Make customer_id nullable
            $table->foreignId('customer_id')->nullable()->change();
            
            // Add new required fields
            $table->foreignId('type_id')->nullable()->after('customer_id')->constrained('types');
            $table->json('customer')->nullable()->after('type_id'); // JSON field for customer data
            $table->decimal('container_price', 10, 2)->nullable()->after('customer');
            $table->integer('no_containers')->nullable()->after('container_price');
            $table->decimal('monthly_dumping_cont', 10, 2)->nullable()->after('no_containers');
            $table->decimal('dumping_cost', 10, 2)->nullable()->after('monthly_dumping_cont');
            $table->decimal('monthly_total_dumping_cost', 10, 2)->nullable()->after('dumping_cost');
            $table->decimal('additional_trip_cost', 10, 2)->nullable()->after('monthly_total_dumping_cost');
            $table->integer('contract_period')->nullable()->after('additional_trip_cost');
            $table->decimal('tax_value', 5, 2)->default(14.00)->after('contract_period');
            $table->decimal('total_payed', 10, 2)->default(0)->after('total_price');
            $table->foreignId('user_id')->nullable()->after('total_payed')->constrained('users');
            
            // Update existing fields
            $table->string('status')->default('pending')->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropForeign(['type_id']);
            $table->dropForeign(['user_id']);
            $table->dropColumn([
                'type_id',
                'customer',
                'container_price',
                'no_containers',
                'monthly_dumping_cont',
                'dumping_cost',
                'monthly_total_dumping_cost',
                'additional_trip_cost',
                'contract_period',
                'tax_value',
                'total_payed',
                'user_id'
            ]);
        });
    }
};
