<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('contract_containers', function (Blueprint $table) {
            // Add type_id column if it doesn't exist
            if (!Schema::hasColumn('contract_containers', 'type_id')) {
                $table->foreignId('type_id')->after('contract_id')->constrained('types')->onDelete('cascade');
            }
            
            // Add container_id column for tracking which specific container is assigned
            if (!Schema::hasColumn('contract_containers', 'container_id')) {
                $table->foreignId('container_id')->nullable()->after('type_id')->constrained('containers')->onDelete('set null');
            }
            
            // Add status tracking
            if (!Schema::hasColumn('contract_containers', 'status')) {
                $table->enum('status', ['assigned', 'filled', 'discharged'])->default('assigned')->after('additional_trip_price');
            }
            if (!Schema::hasColumn('contract_containers', 'filled_at')) {
                $table->timestamp('filled_at')->nullable()->after('status');
            }
            if (!Schema::hasColumn('contract_containers', 'discharged_at')) {
                $table->timestamp('discharged_at')->nullable()->after('filled_at');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('contract_containers', function (Blueprint $table) {
            $table->dropForeign(['type_id']);
            $table->dropForeign(['container_id']);
            $table->dropColumn(['type_id', 'container_id', 'status', 'filled_at', 'discharged_at']);
        });
    }
};
